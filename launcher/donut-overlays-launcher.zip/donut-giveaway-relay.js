#!/usr/bin/env node
/**
 * Giveaways — standalone server
 * -------------------------------------------------------------
 * Free to enter, on purpose. Nobody pays a thing: they type
 *
 *      !theirminecraftname
 *
 * in whichever chat they are watching in, and they are in the draw. That
 * one rule is what keeps this a giveaway rather than a raffle somebody
 * paid for — the moment an entry costs money it is gambling, and that is
 * a line this never goes near.
 *
 * Three ways to show the result, all the same underneath:
 *   chicken   a race across the screen, heads on chickens
 *   boat      the same race on water
 *   number    everybody guesses a number, first exact answer wins
 *
 * The winner of a race is drawn uniformly from EVERY entry — the
 * animation is choreographed around whoever was already drawn, not the
 * other way round. The number game is not a draw at all: it is decided
 * by who typed the right number first.
 *
 * Entries come from the chat people are WATCHING in — Twitch, YouTube
 * and TikTok — and nowhere else. Deliberately not Minecraft chat: a
 * giveaway is for the people watching the stream, and reading the game
 * chat would quietly enter players who are on the server but not in the
 * audience at all.
 *
 * That does mean at least one platform has to be connected before
 * anybody can enter, so the overlay says so in big letters when none
 * is, rather than sitting there taking no entries while you count down.
 *
 * LIVE Studio link source:  http://localhost:8097/display
 * Control panel:            http://localhost:8097/
 */
const http = require('http');
const fs   = require('fs');
const path = require('path');
const os   = require('os');
const crypto = require('crypto');

const BUILD = process.env.DONUT_BUILD || '2026-10-04';
const REV = process.env.DONUT_REV ? '  rev ' + process.env.DONUT_REV : '';
const PORT = 8097;

const chatlinks = require('./chatlinks');

let WebSocketServer;
try { ({ WebSocketServer } = require('ws')); }
catch { ({ WebSocketServer } = require('./ws-lite')); }

const G = {
  phase: 'idle',          // idle | open | racing | done
  mode: 'chicken',        // chicken | boat | number
  prize: '50M',           // whatever you are giving away, in your words
  openSec: 120,           // how long entries stay open
  endsAt: 0,
  entries: [],            // { name, platform, at, guess }
  maxEntries: 500,
  winner: null,           // { name, platform, guess }
  drawnAt: 0,
  /* number mode */
  low: 1,
  high: 100,
  secret: 0,
  revealSecret: false,
  /* look */
  lanes: 8,
  uiScale: 1.15,
  cardW: 26,
  howTo: true,
};
let ign = process.env.DONUT_IGN || 'mrchicken75';
let dirty = true;
let links = null;         // the platform chat reader, once started

const now = () => Date.now();
const mark = () => { dirty = true; };
const say = t => console.log(`  ${new Date().toLocaleTimeString([], {hour12:false})}  ${t}`);
const msLeft = () => (G.phase === 'open' && G.endsAt ? Math.max(0, G.endsAt - now()) : 0);

/* Minecraft names: 3–16 letters, numbers and underscores, with a full
   stop allowed in front for Bedrock. Anything else is somebody typing
   in chat, not entering. */
const NAME_OK = /^[.*]?[A-Za-z0-9_]{3,16}$/;
const key = n => String(n).toLowerCase().replace(/^[.*]/, '');

/* A chat line down to an entry, or null.
   Must START with ! so ordinary chat mentioning a name never enters
   somebody by accident. In the number game a number may follow. */
function readEntry(text){
  const t = String(text || '').trim();
  const m = t.match(/^!\s*([.*]?[A-Za-z0-9_]{3,16})\s*(-?\d{1,9})?\b/);
  if(!m) return null;
  const name = m[1];
  if(!NAME_OK.test(name)) return null;
  return { name, guess: m[2] === undefined ? null : parseInt(m[2], 10) };
}

function add(name, platform, guess){
  if(G.phase !== 'open') return false;
  if(G.entries.length >= G.maxEntries) return false;
  const k = key(name);
  const seen = G.entries.find(e => key(e.name) === k);
  if(seen){
    /* Already in. In the number game a later guess replaces the old one
       — people correct themselves, and refusing that just looks broken.
       In a race a second message changes nothing. */
    if(G.mode === 'number' && guess != null && guess !== seen.guess){
      seen.guess = guess;
      seen.at = now();
      checkNumber(seen);
      mark();
    }
    return false;
  }
  const entry = { name, platform: platform || 'minecraft', at: now(), guess: guess == null ? null : guess };
  G.entries.push(entry);
  say(`${name} entered from ${entry.platform}${entry.guess != null ? ' with ' + entry.guess : ''} · ${G.entries.length} in`);
  if(G.mode === 'number') checkNumber(entry);
  mark();
  return true;
}

/* ---------------- the number game ---------------- */
function checkNumber(entry){
  if(G.mode !== 'number' || G.phase !== 'open') return;
  if(entry.guess == null || !G.secret) return;
  if(entry.guess !== G.secret) return;
  G.phase = 'done';
  G.winner = { name: entry.name, platform: entry.platform, guess: entry.guess };
  G.drawnAt = now();
  G.revealSecret = true;
  G.endsAt = 0;
  say(`WINNER  ${entry.name} guessed ${G.secret} — ${G.prize}`);
  mark();
}
/* Nobody got it exactly: closest wins, and a tie goes to whoever said it
   first. Spelled out on screen before the round starts, so it is never a
   surprise. */
function closest(){
  let best = null;
  for(const e of G.entries){
    if(e.guess == null) continue;
    const d = Math.abs(e.guess - G.secret);
    if(!best || d < best.d || (d === best.d && e.at < best.e.at)) best = { d, e };
  }
  return best ? best.e : null;
}

/* ---------------- running a round ---------------- */
function open(o){
  o = o || {};
  if(o.mode) G.mode = o.mode;
  if(o.prize != null) G.prize = String(o.prize).slice(0, 40);
  if(o.openSec) G.openSec = Math.max(10, Math.min(3600, Number(o.openSec) || 120));
  if(o.low != null) G.low = Math.floor(Number(o.low) || 1);
  if(o.high != null) G.high = Math.floor(Number(o.high) || 100);
  if(G.high <= G.low) G.high = G.low + 1;
  G.entries = []; G.winner = null; G.drawnAt = 0; G.revealSecret = false;
  G.phase = 'open';
  G.endsAt = now() + G.openSec * 1000;
  if(G.mode === 'number'){
    /* Either the number you typed, or one picked here. Picked with the
       same randomness used for keys, not Math.random, because a number
       somebody could predict would be worth money to them. */
    G.secret = Number(o.secret) > 0 ? Math.floor(Number(o.secret))
             : G.low + crypto.randomInt(G.high - G.low + 1);
    say(`number round open — guess between ${G.low} and ${G.high} for ${G.prize}`);
  } else {
    G.secret = 0;
    say(`${G.mode} giveaway open for ${G.openSec}s — ${G.prize}`);
  }
  mark();
}

/* Close entries and decide it. A race runs the animation on the page;
   the result is already settled here. */
function close(){
  if(G.phase !== 'open') return;
  G.endsAt = 0;
  if(!G.entries.length){
    G.phase = 'idle';
    say('nobody entered — nothing given away');
    return mark();
  }
  if(G.mode === 'number'){
    const e = closest();
    G.phase = 'done';
    G.revealSecret = true;
    G.winner = e ? { name: e.name, platform: e.platform, guess: e.guess } : null;
    G.drawnAt = now();
    say(G.winner
      ? `WINNER  ${G.winner.name} was closest to ${G.secret} with ${G.winner.guess}`
      : `nobody guessed — the number was ${G.secret}`);
    return mark();
  }
  /* Uniform over every single entry. crypto.randomInt rather than
     Math.random: this decides who gets real money, and "near enough"
     randomness is not a thing worth being casual about. */
  const pick = G.entries[crypto.randomInt(G.entries.length)];
  G.winner = { name: pick.name, platform: pick.platform, guess: null };
  G.drawnAt = now();
  G.phase = 'racing';
  say(`drawn from ${G.entries.length} entries: ${pick.name} — racing now`);
  mark();
}
/* The page tells us the race has finished so the winner card and the
   result land together on screen. A guard in case the page never does:
   the result is already decided either way. */
function finish(){
  if(G.phase !== 'racing') return;
  G.phase = 'done';
  say(`WINNER  ${G.winner ? G.winner.name : '—'} — ${G.prize}`);
  mark();
}
function reset(){
  G.phase = 'idle'; G.entries = []; G.winner = null; G.endsAt = 0;
  G.drawnAt = 0; G.secret = 0; G.revealSecret = false;
  say('giveaway cleared'); mark();
}
function remove(name){
  const k = key(name);
  const before = G.entries.length;
  G.entries = G.entries.filter(e => key(e.name) !== k);
  if(G.entries.length !== before){ say(`removed ${name}`); mark(); }
}

setInterval(() => {
  if(G.phase === 'open' && G.endsAt && now() >= G.endsAt) close();
}, 200);

/* ---------------- where entries come from ---------------- */
function fromChat({ platform, user, text }){
  const e = readEntry(text);
  if(!e) return;
  add(e.name, platform, e.guess);
}
/* ---------------- commands ---------------- */
function handleCmd(c){
  const a = c.args || {};
  switch(c.name){
    case 'g.open':    open(a); break;
    case 'g.close':   close(); break;
    case 'g.finish':  finish(); break;
    case 'g.reset':   reset(); break;
    case 'g.remove':  remove(a.name); break;
    case 'g.add':     if(G.phase === 'open') add(String(a.name || ''), 'by hand', a.guess == null ? null : Number(a.guess)); break;
    case 'g.config':  for(const k2 of Object.keys(a)) if(k2 in G) G[k2] = a[k2];
                      mark(); break;
    case 'g.links':   if(links) links.update(a || {}); mark(); break;
    case 'g.install': installTikTok(); break;
    case 'config':    if(a.ign){ ign = a.ign; mark(); } break;
  }
}

/* TikTok's library is an optional extra rather than part of the
   download, because most people will never switch it on and nobody
   should wait for an install they do not need. */
let installing = false;
function installTikTok(){
  if(installing) return;
  installing = true;
  say('installing TikTok support — this takes a minute…');
  mark();
  const { spawn } = require('child_process');
  const npmCli = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  const p = spawn(npmCli, ['install', 'tiktok-live-connector', '--no-audit', '--no-fund'],
                  { cwd: __dirname, stdio: 'ignore' });
  p.on('close', code => {
    installing = false;
    say(code === 0
      ? 'TikTok support installed — switch it on in the panel'
      : 'TikTok install failed (npm said ' + code + '). Everything else still works.');
    mark();
  });
  p.on('error', () => {
    installing = false;
    say('TikTok install could not start — npm is not available on this PC.');
    mark();
  });
}

/* ================= http + websocket ================= */
const PAGE = path.join(__dirname, 'donut-giveaway.html');
function isLocal(req){
  const ip = (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
  return /^(::1|127\.|192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ip);
}
const server = http.createServer((req, res) => {
  if(!fs.existsSync(PAGE)){
    res.writeHead(404);
    return res.end('donut-giveaway.html must sit next to this script');
  }
  if(!isLocal(req) && !/^\/(display|overlay)/i.test(req.url || '')){
    res.writeHead(302, { Location: '/display' });
    return res.end();
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  fs.createReadStream(PAGE).pipe(res);
});

/* The secret number is NOT sent out while a round is running: the page
   is served to anybody with the hosted link, and a number sitting in a
   websocket message is a number somebody can read. */
function publicState(){
  /* Only the last couple of hundred entries travel — a thousand of them
     thirty times a second would be a lot of websocket for nothing. The
     TRUE count goes separately as `total`, because the number on screen
     has to be the real one even when the list behind it is trimmed. */
  const out = { ...G, entries: G.entries.slice(-200), total: G.entries.length };
  if(!G.revealSecret) out.secret = 0;
  return out;
}
/* True when at least one platform chat is connected. Without this the
   overlay would happily run a countdown that nobody on earth can enter,
   which is the single worst thing this could do on a live stream. */
function anyChat(){
  const st = links ? links.status().state : null;
  return !!(st && (st.twitch.on || st.youtube.on || st.tiktok.on));
}
/* `full` is only ever true for a panel on this PC. The hosted overlay
   link is a public address, so what travels to it is the round and
   whether a chat is connected — never which channels they are, and
   never anything that could be typed back in somewhere else. */
const payload = (full) => ({
  t: 'state', m: publicState(), s: { ign }, sv: now(), left: msLeft(),
  links: links ? (full ? links.status() : { state: links.status().state }) : null,
  installing: full ? installing : false,
  anyChat: anyChat(),
});
const snapshot = (full) => JSON.stringify(payload(full));

const wss = new WebSocketServer({ server });
const clients = new Set();
wss.on('connection', (ws, req) => {
  const trusted = isLocal(req);
  clients.add(ws);
  ws.trusted = trusted;
  ws.send(snapshot(trusted));
  ws.on('close', () => clients.delete(ws));
  ws.on('message', raw => {
    if(!trusted) return;
    let m; try { m = JSON.parse(raw.toString()); } catch { return; }
    if(m.t === 'cmd') handleCmd(m);
  });
});
setInterval(() => {
  if(!dirty || clients.size === 0) return;
  dirty = false;
  const full = snapshot(true), lean = snapshot(false);
  for(const c of clients) if(c.readyState === 1) c.send(c.trusted ? full : lean);
}, 50);
setInterval(() => { if(G.phase === 'open' && clients.size) mark(); }, 1000).unref();

/* ================= start up ================= */
function lanIP(){
  for(const list of Object.values(os.networkInterfaces()))
    for(const n of list || [])
      if(n.family === 'IPv4' && !n.internal) return n.address;
  return null;
}
const PORT_TRIES = [PORT, PORT + 10, PORT + 20, PORT + 30, PORT + 100];
let portAt = 0, livePort = PORT;
server.on('error', err => {
  if (err && err.code === 'EADDRINUSE' && portAt + 1 < PORT_TRIES.length) {
    portAt += 1; livePort = PORT_TRIES[portAt];
    return server.listen(livePort);
  }
  console.log('  giveaways could not start: ' + (err && err.message ? err.message : err));
});

let announced = false;
server.on('listening', () => {
  if(announced) return;
  announced = true;
  const lan = lanIP();
  console.log(`
  Giveaways   ·   build ${BUILD}${REV}
    overlay       http://localhost:${livePort}/display
    controls      http://localhost:${livePort}/${lan ? `
    on your phone http://${lan}:${livePort}/` : ''}
`);
  links = chatlinks.start({ onChat: fromChat, say });
  mark();
});
server.listen(PORT);

try {
  const uplink = require('./uplink');
  const up = uplink.attach({ getPort: () => livePort, game: 'giveaway', getPayload: () => payload(false) });
  setInterval(() => up.push(), 200).unref();
} catch (e) { /* local only */ }

module.exports = { G, open, close, finish, reset, add, remove, readEntry, fromChat,
                   handleCmd, closest, checkNumber, server, publicState, anyChat };
