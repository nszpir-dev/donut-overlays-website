#!/usr/bin/env node
/**
 * Donut Overlays — launcher
 * ---------------------------------------------------------------
 * The entry point customers actually run. Order matters here:
 *
 *   1. sign in and print the permanent overlay link, while nothing
 *      else is writing to the console
 *   2. only then start the game server, which prints its own banner
 *
 * Doing it the other way round meant the relay's startup text landed
 * on top of the password prompt, and it looked like a hang.
 */
const uplink = require('./uplink');

const GAME = process.env.DONUT_GAME || 'board';

console.log('');
console.log('  Donut Overlays');
console.log('  ------------------------------------------------------------');

uplink.begin(GAME)
  .catch(err => {
    console.log('');
    console.log('  Could not reach donutoverlays.com (' + err.message + ').');
    console.log('  Starting anyway — everything works locally, but your');
    console.log('  permanent overlay link will not update until it is back.');
    console.log('');
    return false;
  })
  .then(() => {
    // Hand over to the game. It reads the Minecraft log, runs the round
    // and serves the local control panel exactly as it always has.
    require('./donut-relay.js');
  });
