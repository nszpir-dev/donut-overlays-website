@echo off
title Donut Overlays
cd /d "%~dp0"

echo.
echo   Donut Overlays - starting up
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo   Node.js is not installed on this PC.
  echo.
  echo   Get it from https://nodejs.org - click the big LTS button,
  echo   install it, then double-click this file again.
  echo.
  pause
  exit /b
)

if not exist "donut-royale.html" (
  echo   donut-royale.html is missing. Every file has to stay
  echo   together in this same folder.
  echo.
  pause
  exit /b
)

if not exist "node_modules\ws" (
  echo   First run - installing the one thing it needs...
  echo.
  call npm install ws --silent
  if errorlevel 1 (
    echo.
    echo   That failed. Check your internet and try again.
    pause
    exit /b
  )
)

echo.
node launcher.js
echo.
echo   Donut Overlays stopped. You can close this window.
pause
