/**
 * Donut Overlays — reading payments out of the Minecraft log
 * ---------------------------------------------------------------
 * All three games need exactly the same thing: notice when somebody pays
 * the streamer in game. This used to be copy-pasted into each relay,
 * which meant a fix for one game silently left the other two broken.
 *
 * Two jobs, and the first one is the one that bites people:
 *
 *   1. FIND THE RIGHT LOG. Barely anyone plays through the vanilla
 *      launcher. Lunar, Badlion, Feather, Prism, Modrinth and the rest
 *      each write their chat somewhere else, and the old code only ever
 *      looked at .minecraft. It would happily say "watching ..." while
 *      pointing at a stale file from a launcher the streamer stopped
 *      using months ago, and then sit there silent forever.
 *
 *   2. READ THE PAY LINE. Servers word these differently, so a miss has
 *      to be loud. Silence is the worst possible outcome — it looks
 *      identical to "nobody paid".
 */
const fs = require('fs');
const os = require('os');
const path = require('path');

/* ---------------- pay-message parsing ---------------- */
/* Donut writes payments like:  VyperJames paid you 💲1M
   Rank prefixes, colour codes and currency symbols all get in the way,
   so these skip anything that is not a digit between the words. */
const PATTERNS = [
  // "VyperJames paid you 💲1M"  ·  "Bob has sent you $1,000,000"
  { re: /([A-Za-z0-9_]{3,16})\s+(?:has\s+|just\s+)?(?:paid|sent|gave|transferred)\s+(?:you|u)\s*\D{0,8}?([\d][\d.,]*)\s*([kmbt])?/i,
    name: 1, num: 2, suf: 3 },
  // "You received 💲1M from VyperJames"  ·  "You have been paid $1M by Bob"
  { re: /(?:you\s+)?(?:have\s+)?(?:received|got|been\s+(?:paid|sent|given))\s*\D{0,8}?([\d][\d.,]*)\s*([kmbt])?\s+(?:from|by)\s+([A-Za-z0-9_]{3,16})/i,
    name: 3, num: 1, suf: 2 },
  // "[+] $1M from VyperJames"
  { re: /\[\+\]\s*\D{0,8}?([\d][\d.,]*)\s*([kmbt])?\s*(?:from\s+)?([A-Za-z0-9_]{3,16})/i,
    name: 3, num: 1, suf: 2 },
  // "$1,000,000 has been sent to you by VyperJames"
  { re: /([\d][\d.,]*)\s*([kmbt])?\s+(?:has\s+been\s+)?(?:sent|paid|given|added|deposited)\s+to\s+(?:you|your\s+\w+)\s+(?:by|from)\s+([A-Za-z0-9_]{3,16})/i,
    name: 3, num: 1, suf: 2 },
  // "VyperJames → You: $1M"  ·  "VyperJames -> you 1M"
  { re: /([A-Za-z0-9_]{3,16})\s*(?:->|→|»|>>)\s*(?:you|u)\s*\D{0,8}?([\d][\d.,]*)\s*([kmbt])?/i,
    name: 1, num: 2, suf: 3 },
];

/* Strip Minecraft colour codes and anything non-printing. */
function clean(line){
  return String(line).replace(/\u00a7./g, '').replace(/[\u0000-\u001f]/g, ' ');
}

function parseAmount(t){
  t = String(t).toLowerCase().replace(/[\s,$_]/g, '');
  const m = t.match(/^(\d+(?:\.\d+)?)([kmbt])?$/);
  if(!m) return 0;
  return Math.floor(parseFloat(m[1]) * ({ k:1e3, m:1e6, b:1e9, t:1e12 }[m[2]] || 1));
}

function parseLine(raw){
  const line = clean(raw);
  for(const p of PATTERNS){
    const m = line.match(p.re);
    if(!m) continue;
    const player = m[p.name];
    const amount = parseAmount((m[p.num] || '') + (m[p.suf] || ''));
    if(player && amount > 0) return { player, amount };
  }
  return null;
}

/* Deliberately generous. A false alarm costs one printed line the
   streamer can ignore; a miss costs them a payment they never see and
   no clue that anything went wrong. Chat from other players talking
   about money is the price of never being silent. */
function looksLikePayment(raw){
  const line = clean(raw);
  if(!/\[CHAT\]/i.test(line)) return false;
  if(!/\d/.test(line)) return false;
  return /(paid|pay|sent|send|received|receive|transferred|given|gave|deposit)/i.test(line)
      || /\[\+\]/.test(line)
      || /[$💲]\s*[\d]/.test(line)
      /* Addressed to "you" and carrying a money-shaped number. Catches a
         wording nobody predicted, at the cost of the odd false alarm on
         ordinary chat — a wasted line in the window is far cheaper than a
         payment vanishing with no trace. */
      || (/\b(you|u|your)\b/i.test(line) && /\b\d[\d.,]*\s*[kmbt]\b|\b\d{4,}\b/i.test(line));
}

/* Money-shaped enough to be worth showing while we are still trying to
   learn what this server's pay message looks like. */
function hasMoneyish(raw){
  const line = clean(raw);
  return /\[CHAT\]/i.test(line) && (/\b\d[\d.,]*\s*[kmbt]\b/i.test(line) || /\b\d{3,}\b/.test(line) || /[$💲]/.test(line));
}

/* ---------------- finding the log ---------------- */
/* Folder names that belong to a Minecraft client of some sort. Anything
   matching gets searched; everything else is skipped, so this never
   turns into a scan of the whole drive. */
const CLIENT_HINT = /(minecraft|lunar|badlion|feather|prism|multimc|modrinth|theseus|curseforge|gdlauncher|technic|tlauncher|salwyrr|labymod|essential|atlauncher|ftb|polymc|xmdlauncher)/i;
const SKIP = /^(node_modules|\.git|windows|program files|programdata|\$recycle\.bin|appdata\\local\\temp)$/i;

function roots(){
  const h = os.homedir();
  const out = [h];
  for(const v of [process.env.APPDATA, process.env.LOCALAPPDATA]) if(v) out.push(v);
  if(process.platform === 'darwin') out.push(path.join(h, 'Library', 'Application Support'));
  return [...new Set(out)];
}

/* Depth-limited walk looking for logs/latest.log. Bounded three ways —
   only into folders that look like a client, only so deep, and only so
   many folders in total — because this runs at startup and a streamer
   waiting on a spinner will just close the window. */
function findLogs(limitMs = 4000){
  const started = Date.now();
  const found = [];
  let looked = 0;

  const walk = (dir, depth, insideClient) => {
    if(depth > 6 || looked > 4000 || Date.now() - started > limitMs) return;
    let list;
    try { list = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    looked++;

    for(const d of list){
      if(!d.isDirectory()) continue;
      if(SKIP.test(d.name)) continue;
      const full = path.join(dir, d.name);

      if(d.name.toLowerCase() === 'logs'){
        for(const name of ['latest.log', 'blclient/minecraft/latest.log']){
          const f = path.join(full, name);
          try {
            const st = fs.statSync(f);
            if(st.isFile()) found.push({ file: f, mtime: st.mtimeMs, size: st.size });
          } catch { /* not there */ }
        }
        continue;                       // no need to go deeper than a logs folder
      }

      /* Only descend into things that look like a Minecraft client, or
         anything at all once we are already inside one (instances,
         profiles, version folders and so on live under there). */
      if(insideClient || CLIENT_HINT.test(d.name)) walk(full, depth + 1, true);
    }
  };

  for(const r of roots()) walk(r, 0, false);

  /* Newest first — the one the game is writing to right now. */
  const seen = new Set();
  return found
    .filter(f => (seen.has(f.file) ? false : seen.add(f.file)))
    .sort((a, b) => b.mtime - a.mtime);
}

const short = p => {
  const h = os.homedir();
  return p.startsWith(h) ? '~' + p.slice(h.length) : p;
};

/* ---------------- the watcher ---------------- */
/**
 * @param {(name:string, amount:number) => void} onPayment
 * @param {(msg:string) => void} say         prints into the game's own log panel
 * @param {boolean} learn                    print every money-ish line
 */
function startTail({ onPayment, say, learn = false }){
  let LOG = process.env.LOG || null;
  let offset = 0, chatSeen = false, reading = false, pendingRead = false;
  let watcher = null, poller = null;

  /* Until a payment has actually been read once, we do not know how this
     server words them. So while nothing has parsed, print every chat line
     with money in it. The real pay message is then sitting in the window
     to be copied — instead of the streamer staring at silence with no way
     to tell anyone what went wrong. Stops the moment one parses. */
  let everParsed = false, shown = 0;
  const SHOW_LIMIT = 25;

  function drain(){
    if(reading || !LOG){ pendingRead = !!LOG; return; }
    let size;
    try { size = fs.statSync(LOG).size; } catch { return; }
    if(size < offset) offset = 0;                 // the log rotated
    if(size === offset) return;

    reading = true;
    const from = offset;
    offset = size;
    const stream = fs.createReadStream(LOG, { start: from, end: size });
    let buf = '';
    stream.on('data', d => buf += d.toString('utf8'));
    stream.on('end', () => {
      reading = false;
      for(const line of buf.split(/\r?\n/)){
        if(!line.trim()) continue;
        if(learn && /\d|paid|sent|received/i.test(line)) console.log('  LEARN | ' + clean(line).trim());
        if(!chatSeen && /\[CHAT\]/i.test(line)){
          chatSeen = true;
          say('chat is coming through — payments will be picked up from here');
        }
        const hit = parseLine(line);
        if(hit){
          if(!everParsed){
            everParsed = true;
            say('payments are being read correctly — that is the last of the chat lines below');
          }
          onPayment(hit.player, hit.amount);
        }
        else if(looksLikePayment(line)) say('COULD NOT READ: ' + clean(line).trim().slice(-110));
        else if(!everParsed && shown < SHOW_LIMIT && hasMoneyish(line)){
          if(shown === 0) say('no payment has been read yet — showing chat lines with money in them:');
          shown++;
          say('   chat | ' + clean(line).replace(/^.*\[CHAT\]\s*/i, '').trim().slice(0, 110));
          if(shown === SHOW_LIMIT) say('   (that is enough examples — send one to us and we will add it)');
        }
      }
      if(pendingRead){ pendingRead = false; drain(); }
    });
    stream.on('error', () => { reading = false; });
  }

  function attach(file, why){
    if(watcher){ try { watcher.close(); } catch {} watcher = null; }
    if(poller){ try { fs.unwatchFile(LOG, poller); } catch {} poller = null; }

    LOG = file;
    try { offset = fs.statSync(LOG).size; } catch { offset = 0; }
    say(`watching ${short(LOG)}${why ? '  (' + why + ')' : ''}`);

    /* fs.watch is event-driven — Windows says the moment the file is
       written, instead of us asking every 150ms. That is the difference
       between a payment landing in ~20ms and up to ~200ms. */
    try { watcher = fs.watch(LOG, { persistent: true }, () => drain()); }
    catch { watcher = null; }
    poller = () => drain();
    fs.watchFile(LOG, { interval: watcher ? 1000 : 100 }, poller);
  }

  const candidates = process.env.LOG ? [] : findLogs();

  if(process.env.LOG){
    attach(process.env.LOG, 'set by hand');
  } else if(candidates.length){
    attach(candidates[0].file, candidates.length > 1 ? `newest of ${candidates.length} found` : '');
    if(candidates.length > 1){
      say('other logs on this PC, in case that is the wrong one:');
      for(const c of candidates.slice(1, 4)) say('   ' + short(c.file));
    }
  } else {
    say('no Minecraft log found on this PC.');
    say('Start Minecraft once, then restart this window.');
    say('Or point at it by hand:  set LOG=C:\\path\\to\\latest.log');
    say('Until then you can still add payments by hand in the panel.');
  }

  /* Two things go wrong after startup, and both look identical to the
     streamer — a dead silent window:
       · Minecraft was opened AFTER this, so a newer log now exists
       · the wrong log was picked out of several
     So keep looking until chat actually shows up, then stop. */
  const hunt = setInterval(() => {
    if(chatSeen || process.env.LOG) return clearInterval(hunt);
    const now = findLogs(1500);
    if(now.length && now[0].file !== LOG && now[0].mtime > (fs.existsSync(LOG || '') ? fs.statSync(LOG).mtimeMs : 0)){
      attach(now[0].file, 'this one is being written to now');
    }
  }, 10000);
  if(hunt.unref) hunt.unref();

  /* Say something after a minute of nothing. Silence is the failure
     mode people cannot debug, so break it. */
  const nag = setTimeout(() => {
    if(chatSeen) return;
    say('');
    say('No chat has come through in the last minute.');
    say('If you are in game and people are talking, the log above is the wrong one.');
    say('Check which launcher you play on, then either:');
    say('   · start the game from that launcher and restart this window, or');
    say('   · set LOG=<full path to that launcher\'s latest.log>');
    say('Everything else works meanwhile — add payments by hand in the panel.');
  }, 60000);
  if(nag.unref) nag.unref();

  return { drain, current: () => LOG, candidates };
}

module.exports = { PATTERNS, clean, parseAmount, parseLine, looksLikePayment, hasMoneyish, findLogs, startTail };
