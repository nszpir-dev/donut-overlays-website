#!/usr/bin/env node
/**
 * Money Game — standalone server
 * -------------------------------------------------------------
 * Everyone pays in. Highest single payment when the clock stops
 * takes the whole pot, minus your cut. Losing payments stay in
 * the pot, so the loser's money is what the winner wins.
 *
 * Payments never stack: bid 1M, someone bids 3M, you now need 4M —
 * and your 1M stays in the pot either way.
 *
 * Late payments (after the clock) can't win. They're logged
 * separately and you keep them.
 *
 * Setup:  npm init -y && npm i ws       (the .bat does this for you)
 * Run:    node donut-money-relay.js
 *         node donut-money-relay.js --learn        (find your pay message)
 *         node donut-money-relay.js --test "line"  (check a pattern)
 *
 * LIVE Studio link source:  http://localhost:8092/display
 * Control panel:            http://localhost:8092/
 */

const http = require('http');
const fs   = require('fs');
const path = require('path');
const os   = require('os');

const PORT = 8092;

/* ================= pay-message parsing =================
   Donut writes payments like:  VyperJames paid you 💲1M
   The currency symbol varies by server and rank prefixes and colour
   codes get in the way, so these patterns skip over anything that
   isn't a digit between "you" and the amount. */
const PATTERNS = [
  // "VyperJames paid you 💲1M"  /  "Bob has sent you $1,000,000"
  { re: /([A-Za-z0-9_]{3,16})\s+(?:has\s+)?(?:paid|sent|gave)\s+(?:you|u)\s*\D{0,6}?([\d][\d.,]*)\s*([kmbt])?/i,
    name: 1, num: 2, suf: 3 },
  // "You received 💲1M from VyperJames"
  { re: /(?:you\s+)?(?:received|got)\s*\D{0,6}?([\d][\d.,]*)\s*([kmbt])?\s+from\s+([A-Za-z0-9_]{3,16})/i,
    name: 3, num: 1, suf: 2 },
  // "[+] $1M from VyperJames"
  { re: /\[\+\]\s*\D{0,6}?([\d][\d.,]*)\s*([kmbt])?\s*(?:from\s+)?([A-Za-z0-9_]{3,16})/i,
    name: 3, num: 1, suf: 2 },
];

/* strip Minecraft colour codes and anything non-printing */
function clean(line){
  return line.replace(/\u00a7./g, '').replace(/[\u0000-\u001f]/g, ' ');
}
function parseAmount(t){
  t = String(t).toLowerCase().replace(/[\s,$_]/g, '');
  const m = t.match(/^(\d+(?:\.\d+)?)([kmbt])?$/);
  if(!m) return 0;
  return Math.floor(parseFloat(m[1]) * ({k:1e3,m:1e6,b:1e9,t:1e12}[m[2]] || 1));
}
function parseLine(raw){
  const line = clean(raw);
  for(const p of PATTERNS){
    const m = line.match(p.re);
    if(!m) continue;
    const player = m[p.name];
    const amount = parseAmount((m[p.num] || '') + (m[p.suf] || ''));
    if(player && amount > 0) return { player, amount };
  }
  return null;
}
/* a line that mentions a payment but didn't parse is worth shouting about */
function looksLikePayment(raw){
  return /(paid|sent|received)\s+(you|u|from)|\[\+\]/i.test(clean(raw));
}

/* ---------- one-off modes ---------- */
const argTest = process.argv.indexOf('--test');
if(argTest > -1){
  console.log(parseLine(process.argv[argTest + 1] || '') || 'no match — add a pattern for this line');
  process.exit(0);
}
const LEARN = process.argv.includes('--learn');

let WebSocketServer;
try { ({ WebSocketServer } = require('ws')); }
catch { console.error('\n  Missing dependency. Run:  npm i ws\n'); process.exit(1); }

/* ================= the money game ================= */
const M = {
  phase: 'idle',          // idle | live | done
  seed: 1000000,          // what you put in to start the pot
  minBid: 0,              // 0 = any amount counts
  cutPct: 10,             // your slice, rolls into the next round
  endsAt: 0,
  paused: false,
  pausedLeft: 0,
  pot: 0,                 // seed + every qualifying payment
  leader: null,           // { name, amount }
  bids: [],               // newest first
  late: [],               // arrived after the clock — you keep these
  kept: 0,                // total of the late ones
  rejected: [],           // under the minimum
  vouches: 6,
  uiScale: 1.15,
  layout: 'compact',
  cardW: 19,
};
let ign = 'mrchicken75';
let dirty = true;

const now = () => Date.now();
const mark = () => { dirty = true; };
const say = t => console.log(`  ${new Date().toLocaleTimeString([], {hour12:false})}  ${t}`);
function money(n){
  if(n >= 1e9) return '$' + +(n/1e9).toFixed(2) + 'B';
  if(n >= 1e6) return '$' + +(n/1e6).toFixed(2) + 'M';
  if(n >= 1e3) return '$' + +(n/1e3).toFixed(1) + 'K';
  return '$' + n;
}
/* what the winner walks away with */
const payout = () => Math.floor(M.pot * (100 - M.cutPct) / 100);
/* your slice of this round, plus anything that turned up late */
const yourCut = () => M.pot - payout() + M.kept;

function mOpen(seed, minBid, sec){
  if(seed != null) M.seed = seed;
  if(minBid != null) M.minBid = minBid;
  M.phase = 'live';
  M.pot = M.seed;
  M.leader = null; M.bids = []; M.late = []; M.kept = 0; M.rejected = [];
  M.paused = false; M.pausedLeft = 0;
  M.endsAt = now() + (sec || 60) * 1000;
  say(`round open · pot starts at ${money(M.seed)} · ${sec || 60}s`);
  mark();
}

function mPay(name, amount){
  name = String(name || '').trim().replace(/[^A-Za-z0-9_]/g, '').slice(0, 16);
  amount = Math.floor(Number(amount) || 0);
  if(!name || amount <= 0) return;

  /* after the clock: can't win, but it's yours */
  if(M.phase !== 'live'){
    M.late.push({ name, amount, at: now() });
    M.kept += amount;
    say(`LATE  ${name} ${money(amount)} — too late to win, you keep it`);
    return mark();
  }
  if(M.minBid > 0 && amount < M.minBid){
    M.rejected.push({ name, amount, why: 'under minimum' });
    say(`REFUND  ${name} ${money(amount)} — under the ${money(M.minBid)} minimum`);
    return mark();
  }

  /* every qualifying payment swells the pot, winning or not */
  M.pot += amount;
  M.bids.unshift({ name, amount, at: now() });
  if(M.bids.length > 15) M.bids.pop();

  if(!M.leader || amount > M.leader.amount){
    M.leader = { name, amount, at: now() };
    say(`LEAD  ${name} ${money(amount)}  ·  pot ${money(M.pot)}  ·  winning ${money(payout())}`);
  } else {
    say(`IN    ${name} ${money(amount)} — does not beat ${money(M.leader.amount)}, stays in the pot`);
  }
  mark();
}

function mEnd(){
  M.phase = 'done';
  M.endsAt = 0;
  if(M.leader) say(`WINNER  ${M.leader.name} takes ${money(payout())} (you keep ${money(yourCut())})`);
  else say('round ended with nobody paying in');
  mark();
}
function mReset(){
  M.phase = 'idle'; M.pot = 0; M.leader = null; M.bids = []; M.late = [];
  M.kept = 0; M.rejected = []; M.endsAt = 0; M.paused = false; M.pausedLeft = 0;
  say('round cleared'); mark();
}
function mTogglePause(){
  M.paused = !M.paused;
  if(M.paused){ M.pausedLeft = M.endsAt ? Math.max(0, M.endsAt - now()) : 0; M.endsAt = 0; }
  else if(M.pausedLeft){ M.endsAt = now() + M.pausedLeft; M.pausedLeft = 0; }
  say(M.paused ? 'paused' : 'resumed'); mark();
}
const addPayment = (name, amount) => mPay(name, amount);

setInterval(() => {
  if(M.phase !== 'live' || M.paused) return;
  if(M.endsAt && now() >= M.endsAt) mEnd();
}, 50);

/* ================= commands from the panel ================= */
function handleCmd(c){
  const a = c.args || {};
  switch(c.name){
    case 'm.open':          mOpen(a.seed, a.minBid, a.sec); break;
    case 'm.pay':           mPay(a.name, a.amount); break;
    case 'm.end':           mEnd(); break;
    case 'm.reset':         mReset(); break;
    case 'm.pause':         mTogglePause(); break;
    case 'm.addTime':       if(M.endsAt){ M.endsAt = Math.max(now(), M.endsAt + Number(a.sec) * 1000); mark(); } break;
    case 'm.undo':          { const b = M.bids.shift();
                              if(b){
                                M.pot -= b.amount;
                                M.leader = M.bids.reduce((best, x) => !best || x.amount > best.amount ? x : best, null);
                                say(`undid ${b.name}'s ${money(b.amount)}`); mark();
                              } } break;
    case 'm.clearRejected': M.rejected = []; mark(); break;
    case 'm.config':        for(const k of Object.keys(a)) if(k in M) M[k] = a[k];
                            say('settings updated'); mark(); break;
    case 'config':          if(a.ign){ ign = a.ign; mark(); } break;
  }
}

/* ================= http + websocket ================= */
const PAGE = path.join(__dirname, 'donut-money.html');

function isLocal(req){
  const ip = (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
  return /^(::1|127\.|192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ip);
}

const server = http.createServer((req, res) => {
  if(!fs.existsSync(PAGE)){
    res.writeHead(404);
    return res.end('donut-money.html must sit next to this script');
  }
  if(!isLocal(req) && !/^\/(display|overlay)/i.test(req.url || '')){
    res.writeHead(302, { Location: '/display' });
    return res.end();
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  fs.createReadStream(PAGE).pipe(res);
});

const wss = new WebSocketServer({ server });
const clients = new Set();
const snapshot = () => JSON.stringify({
  t: 'state', m: M, s: { ign }, payout: payout(), yourCut: yourCut()
});

wss.on('connection', (ws, req) => {
  const trusted = isLocal(req);
  clients.add(ws);
  ws.send(snapshot());
  ws.on('close', () => clients.delete(ws));
  ws.on('message', raw => {
    if(!trusted) return;
    let m; try { m = JSON.parse(raw.toString()); } catch { return; }
    if(m.t === 'cmd') handleCmd(m);
    if(m.t === 'payment') mPay(m.player, m.amount);
  });
  say(`overlay connected (${clients.size} open)${trusted ? '' : ' — view only'}`);
});

setInterval(() => {
  if(!dirty || clients.size === 0) return;
  dirty = false;
  const s = snapshot();
  for(const c of clients) if(c.readyState === 1) c.send(s);
}, 20);

/* ================= minecraft log watcher ================= */
const LOG = process.env.LOG || defaultLog();
function defaultLog(){
  const h = os.homedir();
  return process.platform === 'win32'
    ? path.join(process.env.APPDATA || h, '.minecraft', 'logs', 'latest.log')
    : process.platform === 'darwin'
      ? path.join(h, 'Library', 'Application Support', 'minecraft', 'logs', 'latest.log')
      : path.join(h, '.minecraft', 'logs', 'latest.log');
}
let offset = 0, chatSeen = false, reading = false, pendingRead = false;

/* Read whatever's new since last time. Guarded so overlapping
   notifications can't read the same bytes twice. */
function drain(){
  if(reading){ pendingRead = true; return; }
  let size;
  try { size = fs.statSync(LOG).size; } catch { return; }
  if(size < offset) offset = 0;              // log rotated
  if(size === offset) return;

  reading = true;
  const from = offset, to = size;
  offset = size;
  const stream = fs.createReadStream(LOG, { start: from, end: to });
  let buf = '';
  stream.on('data', d => buf += d.toString('utf8'));
  stream.on('end', () => {
    reading = false;
    for(const line of buf.split(/\r?\n/)){
      if(!line.trim()) continue;
      if(LEARN && /\d|paid|sent|received/i.test(line)) console.log('  LEARN | ' + clean(line).trim());
      if(!chatSeen && /\[CHAT\]/i.test(line)){
        chatSeen = true;
        say('chat is coming through the log — payments will be picked up');
      }
      const hit = parseLine(line);
      if(hit) addPayment(hit.player, hit.amount);
      else if(looksLikePayment(line)) say('COULD NOT READ: ' + clean(line).trim().slice(-90));
    }
    if(pendingRead){ pendingRead = false; drain(); }
  });
  stream.on('error', () => { reading = false; });
}

function startTail(){
  if(!fs.existsSync(LOG)){
    say(`log not found: ${LOG}`);
    say('point at it with:  LOG="C:\\path\\to\\latest.log" node donut-relay.js');
    say('until then add payments by hand in the panel — everything else still works');
    return;
  }
  offset = fs.statSync(LOG).size;
  say(`watching ${LOG}`);

  /* fs.watch is event-driven — Windows tells us the moment the file is
     written, instead of us asking every 150ms. That's the difference
     between a payment landing in ~20ms and up to ~200ms. */
  let watched = false;
  try {
    fs.watch(LOG, { persistent: true }, () => drain());
    watched = true;
  } catch { /* falls through to polling */ }

  /* a slow poll as a safety net — some setups don't fire watch events */
  fs.watchFile(LOG, { interval: watched ? 1000 : 100 }, () => drain());
}

/* your PC's address on the wifi, so you can drive the panel from your phone */
function lanIP(){
  for(const list of Object.values(os.networkInterfaces()))
    for(const n of list || [])
      if(n.family === 'IPv4' && !n.internal) return n.address;
  return null;
}
function lanIP(){
  for(const list of Object.values(os.networkInterfaces()))
    for(const n of list || [])
      if(n.family === 'IPv4' && !n.internal) return n.address;
  return null;
}

server.listen(PORT, () => {
  const lan = lanIP();
  console.log(`
  Money Game is running   (leave this window open — minimising is fine)

    LIVE Studio link source   http://localhost:${PORT}/display
    ...or if it rejects that  http://127.0.0.1:${PORT}/display${lan ? `
    ...or this one            http://${lan}:${PORT}/display` : ''}
    control panel on this PC  http://localhost:${PORT}/
${lan ? `    control panel on your phone  http://${lan}:${PORT}/   (same wifi)` : ''}
`);
  startTail();
  if(LEARN) say('learn mode on — every money-ish log line prints below.');
});


/* ================= Donut Overlays uplink =================
   Mirrors this game up to donutoverlays.com so the streamer's permanent
   overlay link shows it. The game still runs entirely on this PC; if the
   site is unreachable everything above carries on exactly as before. */
try {
  const uplink = require('./uplink');
  const up = uplink.attach({ game: 'money', getPayload: () => ({ t: 'state', m: M, s: { ign }, payout: payout(), yourCut: yourCut() }) });
  setInterval(() => up.push(), 50).unref();
} catch (e) {
  console.log('  uplink unavailable (' + e.message + ') — running locally only');
}
