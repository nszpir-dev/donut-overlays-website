#!/usr/bin/env node
/**
 * Donut Auction — standalone server
 * -------------------------------------------------------------
 * Its own program, its own folder, its own port (8091). Nothing
 * here touches the elimination board, so you can only ever run
 * one game against your Minecraft chat at a time.
 *
 * The auction runs HERE, not in the browser — a minimised browser
 * window gets throttled by Windows and the clock would drift.
 *
 * Setup:  npm init -y && npm i ws        (the .bat does this for you)
 * Run:    node donut-auction-relay.js
 *         node donut-auction-relay.js --learn         (find your pay message)
 *         node donut-auction-relay.js --test "line"   (check a pattern)
 *
 * TikTok LIVE Studio -> Link source:
 *   http://localhost:8091/display
 * Your control panel -> any browser:
 *   http://localhost:8091/
 */

const http = require('http');
const fs   = require('fs');
const path = require('path');
const os   = require('os');

const PORT = 8091;

/* ================= pay-message parsing =================
   Donut writes payments like:  VyperJames paid you 💲1M
   The currency symbol varies by server and rank prefixes and colour
   codes get in the way, so these patterns skip over anything that
   isn't a digit between "you" and the amount. */
const PATTERNS = [
  // "VyperJames paid you 💲1M"  /  "Bob has sent you $1,000,000"
  { re: /([A-Za-z0-9_]{3,16})\s+(?:has\s+)?(?:paid|sent|gave)\s+(?:you|u)\s*\D{0,6}?([\d][\d.,]*)\s*([kmbt])?/i,
    name: 1, num: 2, suf: 3 },
  // "You received 💲1M from VyperJames"
  { re: /(?:you\s+)?(?:received|got)\s*\D{0,6}?([\d][\d.,]*)\s*([kmbt])?\s+from\s+([A-Za-z0-9_]{3,16})/i,
    name: 3, num: 1, suf: 2 },
  // "[+] $1M from VyperJames"
  { re: /\[\+\]\s*\D{0,6}?([\d][\d.,]*)\s*([kmbt])?\s*(?:from\s+)?([A-Za-z0-9_]{3,16})/i,
    name: 3, num: 1, suf: 2 },
];

/* strip Minecraft colour codes and anything non-printing */
function clean(line){
  return line.replace(/\u00a7./g, '').replace(/[\u0000-\u001f]/g, ' ');
}
function parseAmount(t){
  t = String(t).toLowerCase().replace(/[\s,$_]/g, '');
  const m = t.match(/^(\d+(?:\.\d+)?)([kmbt])?$/);
  if(!m) return 0;
  return Math.floor(parseFloat(m[1]) * ({k:1e3,m:1e6,b:1e9,t:1e12}[m[2]] || 1));
}
function parseLine(raw){
  const line = clean(raw);
  for(const p of PATTERNS){
    const m = line.match(p.re);
    if(!m) continue;
    const player = m[p.name];
    const amount = parseAmount((m[p.num] || '') + (m[p.suf] || ''));
    if(player && amount > 0) return { player, amount };
  }
  return null;
}
/* a line that mentions a payment but didn't parse is worth shouting about */
function looksLikePayment(raw){
  return /(paid|sent|received)\s+(you|u|from)|\[\+\]/i.test(clean(raw));
}

/* ---------- one-off modes ---------- */
const argTest = process.argv.indexOf('--test');
if(argTest > -1){
  console.log(parseLine(process.argv[argTest + 1] || '') || 'no match — add a pattern for this line');
  process.exit(0);
}
const LEARN = process.argv.includes('--learn');

let WebSocketServer;
try { ({ WebSocketServer } = require('ws')); }
catch { console.error('\n  Missing dependency. Run:  npm i ws\n'); process.exit(1); }

/* ================= the auction ================= */
const A = {
  phase: 'idle',          // idle | live | sold
  item: '',
  minBid: 1000000,
  endsAt: 0,
  delaySec: 5,            // keeps taking bids this long after 0:00
  inDelay: false,
  delayEndsAt: 0,
  paused: false,
  pausedLeft: 0,
  high: null,             // { name, amount }
  bids: [],               // accepted bids, newest first
  rejected: [],           // paid but not a valid bid — refund these
  vouches: 6,
  uiScale: 1.15,          // Text size dropdown — the overlay reads this
  layout: 'compact',      // compact = only item, bid and clock
  cardW: 19,              // card width in rem; 100 = full width
};
let ign = 'mrchicken75';
let dirty = true;

const now = () => Date.now();
const mark = () => { dirty = true; };
const say = t => console.log(`  ${new Date().toLocaleTimeString([], {hour12:false})}  ${t}`);
function money(n){
  if(n >= 1e9) return '$' + +(n/1e9).toFixed(2) + 'B';
  if(n >= 1e6) return '$' + +(n/1e6).toFixed(2) + 'M';
  if(n >= 1e3) return '$' + +(n/1e3).toFixed(1) + 'K';
  return '$' + n;
}

function aOpen(item, minBid, sec){
  if(item) A.item = item;
  if(minBid != null) A.minBid = minBid;   // 0 is a real minimum
  A.phase = 'live';
  A.high = null; A.bids = []; A.rejected = [];
  A.inDelay = false; A.delayEndsAt = 0; A.paused = false;
  A.endsAt = now() + (sec || 60) * 1000;
  say(`auction open: ${A.item || '(no item)'} · min ${money(A.minBid)} · ${sec || 60}s`);
  mark();
}

/* Bids never stack. 5M then 10M from the same person is a 10M bid,
   not 15M — anything that doesn't beat the leader gets refunded. */
function aBid(name, amount){
  name = String(name || '').trim().replace(/[^A-Za-z0-9_]/g, '').slice(0, 16);
  amount = Math.floor(Number(amount) || 0);
  if(!name || amount <= 0) return;

  if(A.phase !== 'live'){
    A.rejected.push({ name, amount, why: 'auction not running' });
    say(`REFUND  ${name} ${money(amount)} — auction not running`);
    return mark();
  }
  if(amount < A.minBid){
    A.rejected.push({ name, amount, why: 'under minimum' });
    say(`REFUND  ${name} ${money(amount)} — under the ${money(A.minBid)} minimum`);
    return mark();
  }
  if(A.high && amount <= A.high.amount){
    A.rejected.push({ name, amount, why: `under ${A.high.name}'s ${money(A.high.amount)}` });
    say(`REFUND  ${name} ${money(amount)} — does not beat ${money(A.high.amount)}`);
    return mark();
  }
  A.high = { name, amount, at: now() };
  A.bids.unshift({ name, amount, at: now() });
  if(A.bids.length > 12) A.bids.pop();
  say(`BID  ${name}  ${money(amount)}`);
  mark();
}
function aClose(){
  A.phase = 'sold'; A.inDelay = false; A.endsAt = 0;
  say(A.high ? `SOLD to ${A.high.name} for ${money(A.high.amount)}` : 'ended with no bids');
  mark();
}
function aReset(){
  A.phase = 'idle'; A.item = ''; A.high = null; A.bids = []; A.rejected = [];
  A.endsAt = 0; A.inDelay = false; A.delayEndsAt = 0; A.paused = false; A.pausedLeft = 0;
  say('auction cleared'); mark();
}
function aTogglePause(){
  A.paused = !A.paused;
  if(A.paused){ A.pausedLeft = A.endsAt ? Math.max(0, A.endsAt - now()) : 0; A.endsAt = 0; }
  else if(A.pausedLeft){ A.endsAt = now() + A.pausedLeft; A.pausedLeft = 0; }
  say(A.paused ? 'paused' : 'resumed'); mark();
}
const addPayment = (name, amount) => aBid(name, amount);   // chat money = a bid

/* the clock: at zero it either sells, or keeps taking bids through
   the live-delay window so stream-lag bids still count */
setInterval(() => {
  if(A.phase !== 'live' || A.paused) return;
  if(A.endsAt && now() >= A.endsAt){
    if(A.delaySec > 0 && !A.inDelay){
      A.inDelay = true;
      A.delayEndsAt = now() + A.delaySec * 1000;
      say(`clock hit zero — still taking bids for ${A.delaySec}s (live delay)`);
      mark();
    } else if(!A.inDelay || now() >= A.delayEndsAt){
      aClose();
    }
  }
}, 50);

/* ================= commands from the panel ================= */
function handleCmd(c){
  const a = c.args || {};
  switch(c.name){
    case 'a.open':          aOpen(a.item, a.minBid, a.sec); break;
    case 'a.bid':           aBid(a.name, a.amount); break;
    case 'a.close':         aClose(); break;
    case 'a.reset':         aReset(); break;
    case 'a.pause':         aTogglePause(); break;
    case 'a.addTime':       if(A.endsAt){ A.endsAt = Math.max(now(), A.endsAt + Number(a.sec) * 1000); mark(); } break;
    case 'a.time':          if(a.sec != null){ A.endsAt = now() + Number(a.sec) * 1000; A.inDelay = false; mark(); } break;
    case 'a.undo':          { const b = A.bids.shift();
                              if(b){ A.high = A.bids[0] || null; say(`undid ${b.name}'s bid`); mark(); } } break;
    case 'a.clearRejected': A.rejected = []; mark(); break;
    case 'a.config':        for(const k of Object.keys(a)) if(k in A) A[k] = a[k];
                            say('settings updated'); mark(); break;
    case 'config':          if(a.ign){ ign = a.ign; mark(); } break;
  }
}

/* ================= http + websocket ================= */
const PAGE = path.join(__dirname, 'donut-auction.html');

/* a tunnel link is public, so only this PC and your own wifi get to
   press buttons — everyone else just watches */
function isLocal(req){
  const ip = (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
  return /^(::1|127\.|192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ip);
}

const server = http.createServer((req, res) => {
  if(!fs.existsSync(PAGE)){
    res.writeHead(404);
    return res.end('donut-auction.html must sit next to this script');
  }
  if(!isLocal(req) && !/^\/(display|overlay|auction-display)/i.test(req.url || '')){
    res.writeHead(302, { Location: '/display' });
    return res.end();
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  fs.createReadStream(PAGE).pipe(res);
});

const wss = new WebSocketServer({ server });
const clients = new Set();

wss.on('connection', (ws, req) => {
  const trusted = isLocal(req);
  clients.add(ws);
  ws.send(JSON.stringify({ t: 'state', a: A, s: { ign } }));
  ws.on('close', () => clients.delete(ws));
  ws.on('message', raw => {
    if(!trusted) return;
    let m; try { m = JSON.parse(raw.toString()); } catch { return; }
    if(m.t === 'cmd') handleCmd(m);
    if(m.t === 'payment') aBid(m.player, m.amount);
  });
  say(`overlay connected (${clients.size} open)${trusted ? '' : ' — view only'}`);
});

setInterval(() => {
  if(!dirty || clients.size === 0) return;
  dirty = false;
  const s = JSON.stringify({ t: 'state', a: A, s: { ign } });
  for(const c of clients) if(c.readyState === 1) c.send(s);
}, 20);

/* ================= minecraft log watcher ================= */
const LOG = process.env.LOG || defaultLog();
function defaultLog(){
  const h = os.homedir();
  return process.platform === 'win32'
    ? path.join(process.env.APPDATA || h, '.minecraft', 'logs', 'latest.log')
    : process.platform === 'darwin'
      ? path.join(h, 'Library', 'Application Support', 'minecraft', 'logs', 'latest.log')
      : path.join(h, '.minecraft', 'logs', 'latest.log');
}
let offset = 0, chatSeen = false, reading = false, pendingRead = false;

/* Read whatever's new since last time. Guarded so overlapping
   notifications can't read the same bytes twice. */
function drain(){
  if(reading){ pendingRead = true; return; }
  let size;
  try { size = fs.statSync(LOG).size; } catch { return; }
  if(size < offset) offset = 0;              // log rotated
  if(size === offset) return;

  reading = true;
  const from = offset, to = size;
  offset = size;
  const stream = fs.createReadStream(LOG, { start: from, end: to });
  let buf = '';
  stream.on('data', d => buf += d.toString('utf8'));
  stream.on('end', () => {
    reading = false;
    for(const line of buf.split(/\r?\n/)){
      if(!line.trim()) continue;
      if(LEARN && /\d|paid|sent|received/i.test(line)) console.log('  LEARN | ' + clean(line).trim());
      if(!chatSeen && /\[CHAT\]/i.test(line)){
        chatSeen = true;
        say('chat is coming through the log — payments will be picked up');
      }
      const hit = parseLine(line);
      if(hit) addPayment(hit.player, hit.amount);
      else if(looksLikePayment(line)) say('COULD NOT READ: ' + clean(line).trim().slice(-90));
    }
    if(pendingRead){ pendingRead = false; drain(); }
  });
  stream.on('error', () => { reading = false; });
}

function startTail(){
  if(!fs.existsSync(LOG)){
    say(`log not found: ${LOG}`);
    say('point at it with:  LOG="C:\\path\\to\\latest.log" node donut-relay.js');
    say('until then add payments by hand in the panel — everything else still works');
    return;
  }
  offset = fs.statSync(LOG).size;
  say(`watching ${LOG}`);

  /* fs.watch is event-driven — Windows tells us the moment the file is
     written, instead of us asking every 150ms. That's the difference
     between a payment landing in ~20ms and up to ~200ms. */
  let watched = false;
  try {
    fs.watch(LOG, { persistent: true }, () => drain());
    watched = true;
  } catch { /* falls through to polling */ }

  /* a slow poll as a safety net — some setups don't fire watch events */
  fs.watchFile(LOG, { interval: watched ? 1000 : 100 }, () => drain());
}

/* your PC's address on the wifi, so you can drive the panel from your phone */
function lanIP(){
  for(const list of Object.values(os.networkInterfaces()))
    for(const n of list || [])
      if(n.family === 'IPv4' && !n.internal) return n.address;
  return null;
}
/* your PC's address on the wifi, so you can run the panel from your phone */
function lanIP(){
  for(const list of Object.values(os.networkInterfaces()))
    for(const n of list || [])
      if(n.family === 'IPv4' && !n.internal) return n.address;
  return null;
}

server.listen(PORT, () => {
  const lan = lanIP();
  console.log(`
  Donut Auction is running   (leave this window open — minimising is fine)

    LIVE Studio link source   http://localhost:${PORT}/display
    ...or if it rejects that  http://127.0.0.1:${PORT}/display${lan ? `
    ...or this one            http://${lan}:${PORT}/display` : ''}
    control panel on this PC  http://localhost:${PORT}/
${lan ? `    control panel on your phone  http://${lan}:${PORT}/   (same wifi)` : ''}
`);
  startTail();
  if(LEARN) say('learn mode on — every money-ish log line prints below.');
});


/* ================= Donut Overlays uplink =================
   Mirrors this game up to donutoverlays.com so the streamer's permanent
   overlay link shows it. The game still runs entirely on this PC; if the
   site is unreachable everything above carries on exactly as before. */
try {
  const uplink = require('./uplink');
  const up = uplink.attach({ game: 'auction', getPayload: () => ({ t: 'state', a: A, s: { ign } }) });
  setInterval(() => up.push(), 50).unref();
} catch (e) {
  console.log('  uplink unavailable (' + e.message + ') — running locally only');
}
