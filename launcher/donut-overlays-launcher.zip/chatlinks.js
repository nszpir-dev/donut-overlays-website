/**
 * Donut Overlays — reading chat from the platforms
 * ---------------------------------------------------------------
 * The giveaway needs to see people typing in whichever chat they are
 * watching in. Three connections, deliberately kept apart so one going
 * wrong cannot take the others down with it:
 *
 *   Twitch    read-only, anonymous. No login, no key, no permission —
 *             Twitch lets anyone read a public chat, so all this needs
 *             is the channel name. The sturdiest of the three.
 *
 *   YouTube   the official Data API. Needs a free Google API key and the
 *             live video's address. Google gives a daily quota, so the
 *             poll rate follows whatever interval YouTube itself asks
 *             for rather than hammering it.
 *
 *   TikTok    there is no official way in. This uses the same unofficial
 *             library the old Follow Reel used, which is exactly why
 *             that was withdrawn: it works until TikTok changes
 *             something, then it does not. It is off unless switched on,
 *             it says plainly when it breaks, and nothing else depends
 *             on it.
 *
 * None of it is required. With all three off, people still enter by
 * typing in Minecraft chat, which cannot break because the launcher is
 * already reading that log for payments.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');

let WebSocket;
try { ({ WebSocket } = require('ws')); }
catch { ({ WebSocket } = require('./ws-lite')); }

/* Channel names and the YouTube key live on this PC and nowhere else.
   They are not sent to donutoverlays.com and they are not in the zip. */
const CONF = path.join(os.homedir(), '.donut-chat.json');

const DEFAULTS = {
  twitch:  { on: false, channel: '' },
  youtube: { on: false, apiKey: '', video: '' },
  tiktok:  { on: false, user: '' },
};

function readConf(){
  try {
    const o = JSON.parse(fs.readFileSync(CONF, 'utf8'));
    return {
      twitch:  { ...DEFAULTS.twitch,  ...(o.twitch  || {}) },
      youtube: { ...DEFAULTS.youtube, ...(o.youtube || {}) },
      tiktok:  { ...DEFAULTS.tiktok,  ...(o.tiktok  || {}) },
    };
  } catch { return JSON.parse(JSON.stringify(DEFAULTS)); }
}
function writeConf(c){
  try { fs.writeFileSync(CONF, JSON.stringify(c, null, 2), { mode: 0o600 }); } catch { /* not fatal */ }
}

/* A YouTube address in any of its shapes down to the video id. */
function videoId(v){
  const s = String(v || '').trim();
  if(/^[A-Za-z0-9_-]{11}$/.test(s)) return s;
  const m = s.match(/(?:v=|youtu\.be\/|live\/|embed\/|shorts\/)([A-Za-z0-9_-]{11})/);
  return m ? m[1] : '';
}
const cleanChannel = v => String(v || '').trim().replace(/^.*twitch\.tv\//i, '').replace(/[^A-Za-z0-9_]/g, '').toLowerCase();
const cleanTikTok  = v => String(v || '').trim().replace(/^.*tiktok\.com\/@?/i, '').replace(/^@/, '').replace(/[^A-Za-z0-9_.]/g, '');

function getJSON(url){
  return new Promise((resolve, reject) => {
    const req = https.get(url, res => {
      let body = '';
      res.on('data', d => body += d);
      res.on('end', () => {
        let data = null;
        try { data = JSON.parse(body); } catch { return reject(new Error('unreadable answer')); }
        if(res.statusCode >= 400){
          const msg = (data && data.error && data.error.message) || ('HTTP ' + res.statusCode);
          return reject(new Error(msg));
        }
        resolve(data);
      });
    });
    req.setTimeout(12000, () => req.destroy(new Error('timed out')));
    req.on('error', reject);
  });
}

/* ================= the three connections ================= */
function start({ onChat, say }){
  let conf = readConf();
  const state = {
    twitch:  { on: false, note: 'off' },
    youtube: { on: false, note: 'off' },
    tiktok:  { on: false, note: 'off' },
  };
  const live = { twitch: null, youtube: null, tiktok: null };
  const tell = t => { try { say && say(t); } catch {} };
  const hand = (platform, user, text) => {
    if(!user || !text) return;
    try { onChat({ platform, user: String(user).slice(0, 40), text: String(text).slice(0, 200) }); }
    catch { /* a bad entry must never kill the connection */ }
  };

  /* ---------------- Twitch ---------------- */
  function stopTwitch(){
    if(live.twitch){ try { live.twitch.stop = true; live.twitch.ws && live.twitch.ws.close(); } catch {} }
    live.twitch = null;
    state.twitch = { on: false, note: 'off' };
  }
  function startTwitch(){
    stopTwitch();
    const channel = cleanChannel(conf.twitch.channel);
    if(!conf.twitch.on || !channel){ return; }
    const h = { stop: false, ws: null, tries: 0 };
    live.twitch = h;
    const open = () => {
      if(h.stop) return;
      let ws;
      try { ws = new WebSocket('wss://irc-ws.chat.twitch.tv:443'); }
      catch(e){ return retry(e.message); }
      h.ws = ws;
      ws.on('open', () => {
        h.tries = 0;
        /* justinfan is Twitch's own anonymous reader account. No
           password, no account of yours involved at all. */
        ws.send('PASS SCHMOOPIIE\r\n');
        ws.send('NICK justinfan' + (10000 + Math.floor(Math.random() * 80000)) + '\r\n');
        ws.send('JOIN #' + channel + '\r\n');
        state.twitch = { on: true, note: 'reading #' + channel };
        tell('twitch chat connected (#' + channel + ')');
      });
      ws.on('message', raw => {
        const text = raw.toString();
        if(text.startsWith('PING')) return ws.send('PONG :tmi.twitch.tv\r\n');
        for(const line of text.split('\r\n')){
          const m = line.match(/^:([^!]+)![^ ]+ PRIVMSG #[^ ]+ :(.*)$/);
          if(m) hand('twitch', m[1], m[2]);
        }
      });
      ws.on('error', () => {});
      ws.on('close', () => { if(!h.stop) retry('connection closed'); });
    };
    const retry = why => {
      state.twitch = { on: false, note: 'reconnecting (' + why + ')' };
      h.tries++;
      setTimeout(open, Math.min(30000, 2000 * h.tries));
    };
    open();
  }

  /* ---------------- YouTube ---------------- */
  function stopYouTube(){
    if(live.youtube){ live.youtube.stop = true; clearTimeout(live.youtube.timer); }
    live.youtube = null;
    state.youtube = { on: false, note: 'off' };
  }
  async function startYouTube(){
    stopYouTube();
    const key = String(conf.youtube.apiKey || '').trim();
    const vid = videoId(conf.youtube.video);
    if(!conf.youtube.on || !key || !vid) return;
    const h = { stop: false, timer: null, page: '' };
    live.youtube = h;
    try {
      const info = await getJSON(`https://www.googleapis.com/youtube/v3/videos?part=liveStreamingDetails&id=${vid}&key=${encodeURIComponent(key)}`);
      const item = (info.items || [])[0];
      const chatId = item && item.liveStreamingDetails && item.liveStreamingDetails.activeLiveChatId;
      if(!chatId){
        state.youtube = { on: false, note: 'that video has no live chat running' };
        return tell('youtube: that video is not live, or its chat is off');
      }
      state.youtube = { on: true, note: 'reading live chat' };
      tell('youtube chat connected');
      const poll = async () => {
        if(h.stop) return;
        try {
          const url = `https://www.googleapis.com/youtube/v3/liveChat/messages?liveChatId=${encodeURIComponent(chatId)}`
            + `&part=snippet,authorDetails&maxResults=200&key=${encodeURIComponent(key)}`
            + (h.page ? `&pageToken=${encodeURIComponent(h.page)}` : '');
          const data = await getJSON(url);
          h.page = data.nextPageToken || '';
          for(const m of data.items || []){
            const text = m.snippet && (m.snippet.displayMessage || (m.snippet.textMessageDetails || {}).messageText);
            const who = m.authorDetails && m.authorDetails.displayName;
            hand('youtube', who, text);
          }
          /* Google says how often to come back. Ignoring it is how a
             free quota disappears before lunchtime. */
          const wait = Math.max(2000, Number(data.pollingIntervalMillis) || 5000);
          h.timer = setTimeout(poll, wait);
        } catch(e){
          state.youtube = { on: false, note: e.message };
          tell('youtube chat stopped: ' + e.message);
          h.timer = setTimeout(poll, 30000);
        }
      };
      poll();
    } catch(e){
      state.youtube = { on: false, note: e.message };
      tell('youtube could not start: ' + e.message);
    }
  }

  /* ---------------- TikTok ---------------- */
  function stopTikTok(){
    if(live.tiktok){
      live.tiktok.stop = true;
      try { live.tiktok.conn && live.tiktok.conn.disconnect(); } catch {}
    }
    live.tiktok = null;
    state.tiktok = { on: false, note: 'off' };
  }
  async function startTikTok(){
    stopTikTok();
    const user = cleanTikTok(conf.tiktok.user);
    if(!conf.tiktok.on || !user) return;
    const h = { stop: false, conn: null };
    live.tiktok = h;
    let lib = null;
    try { lib = require('tiktok-live-connector'); }
    catch {
      state.tiktok = { on: false, note: 'needs a one-time install — press the button in the panel' };
      return tell('tiktok support is not installed yet — the Install button in the giveaway panel sets it up');
    }
    try {
      /* The package has shipped as both CommonJS and ESM with different
         names for the same class. Take whichever is there rather than
         assuming, because guessing wrong is a crash on somebody's
         stream. */
      const Ctor = lib.WebcastPushConnection || lib.TikTokLiveConnection || (lib.default && (lib.default.WebcastPushConnection || lib.default.TikTokLiveConnection));
      if(!Ctor) throw new Error('this version of the tiktok library is not one we know');
      const conn = new Ctor(user, {});
      h.conn = conn;
      conn.on('chat', d => hand('tiktok', d.uniqueId || d.nickname, d.comment));
      conn.on('disconnected', () => {
        if(h.stop) return;
        state.tiktok = { on: false, note: 'disconnected — trying again' };
        setTimeout(() => { if(!h.stop) startTikTok(); }, 10000);
      });
      await conn.connect();
      state.tiktok = { on: true, note: 'reading @' + user };
      tell('tiktok chat connected (@' + user + ')');
    } catch(e){
      /* Almost always "not live right now". Said plainly, and retried,
         because people set this up before they go live. */
      state.tiktok = { on: false, note: String(e && e.message || e).slice(0, 90) };
      tell('tiktok chat not connected: ' + String(e && e.message || e).slice(0, 90));
      if(!h.stop) setTimeout(() => { if(!h.stop) startTikTok(); }, 20000);
    }
  }

  function applyAll(){
    startTwitch();
    startYouTube();
    startTikTok();
  }
  applyAll();

  return {
    status: () => ({
      conf: {
        twitch: { on: !!conf.twitch.on, channel: conf.twitch.channel || '' },
        /* The key is never sent to the page — only whether there is one. */
        youtube: { on: !!conf.youtube.on, video: conf.youtube.video || '', hasKey: !!(conf.youtube.apiKey || '').trim() },
        tiktok: { on: !!conf.tiktok.on, user: conf.tiktok.user || '' },
      },
      state,
    }),
    update(next){
      conf = {
        twitch:  { ...conf.twitch,  ...(next.twitch  || {}) },
        youtube: { ...conf.youtube, ...(next.youtube || {}) },
        tiktok:  { ...conf.tiktok,  ...(next.tiktok  || {}) },
      };
      /* An empty key means "leave it alone", so the panel never has to
         send the saved one back and forth. */
      if(next.youtube && next.youtube.apiKey === '') conf.youtube.apiKey = readConf().youtube.apiKey;
      writeConf(conf);
      applyAll();
    },
    stop(){ stopTwitch(); stopYouTube(); stopTikTok(); },
  };
}

module.exports = { start, readConf, writeConf, videoId, cleanChannel, cleanTikTok, CONF };
