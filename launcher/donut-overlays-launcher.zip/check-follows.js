/**
 * Donut Overlays — the follows self-check
 * ---------------------------------------------------------------
 * Why this exists.
 *
 * "The follows do not work" has at least eight distinct causes, and
 * from the outside every one of them looks identical: a reel that never
 * spins. Working out which one it is has taken several rounds of
 * screenshots each time, and every round costs the streamer a stream.
 *
 * So this asks all eight questions in one go and writes the answers to
 * a file that can simply be sent to somebody. It changes nothing, spins
 * nothing, and needs no account — it can be run while the launcher is
 * open or closed, live or not live.
 *
 * It deliberately reuses the launcher's own loader rather than
 * re-implementing the checks. A self-check that answers differently
 * from the thing it is checking is worse than no self-check at all.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const net = require('net');

const OUT = path.join(__dirname, 'follows-report.txt');
const lines = [];
const say = t => { console.log(t); lines.push(t); };
const head = t => { say(''); say(t); say('-'.repeat(t.length)); };

/* Never let the check itself be the thing that fails. Every question is
   wrapped: an unanswerable one is reported as unanswerable and the rest
   still run. */
const tryHard = (fn, fallback) => { try { return fn(); } catch (e) { return fallback ?? ('could not tell — ' + e.message); } };

function readName(file, strip){
  return tryHard(() => {
    const v = fs.readFileSync(path.join(__dirname, file), 'utf8').trim();
    return strip ? v.replace(/^@+/, '') : v;
  }, '(not set)');
}

function portFree(port){
  return new Promise(resolve => {
    const s = net.createServer();
    s.once('error', () => resolve(false));
    s.once('listening', () => s.close(() => resolve(true)));
    s.listen(port, '127.0.0.1');
  });
}

(async () => {
  say('DONUT OVERLAYS — FOLLOWS CHECK');
  say(new Date().toString());

  head('1. WHICH COPY IS THIS');
  const boot = tryHard(() => fs.readFileSync(path.join(__dirname, 'launcher.js'), 'utf8'), '');
  const stamp = /const BUILD = '([^']+)'/.exec(boot);
  say('build          ' + (stamp ? stamp[1] : 'UNKNOWN — launcher.js is missing or very old'));
  say('revision       ' + tryHard(() => require('./update').revision() || '(none)', '(this copy predates revisions)'));
  say('folder         ' + __dirname);
  for (const f of ['tiktok-follows.js', 'get-tiktok.js', 'update.js']) {
    say((f + ' ').padEnd(15) + (fs.existsSync(path.join(__dirname, f)) ? 'present' : 'MISSING — this copy is too old'));
  }
  /* The single most useful line in the whole report: whether the fix for
     the library's constructor bug is actually in this folder. */
  const tf = tryHard(() => fs.readFileSync(path.join(__dirname, 'tiktok-follows.js'), 'utf8'), '');
  say('constructor fix ' + (/const SHAPES = \[/.test(tf) ? 'present' : 'MISSING — this is an older copy than you think'));

  head('2. NODE');
  say('version        ' + process.version);
  const major = Number((/^v?(\d+)/.exec(process.version) || [])[1] || 0);
  say('good enough    ' + (major >= 20 ? 'yes' : 'NO — the TikTok listener needs Node 20 or newer'));

  head('3. THE TIKTOK LISTENER');
  let follows = null;
  try { follows = require('./tiktok-follows'); }
  catch (e) { say('could not even load tiktok-follows.js — ' + e.message); }

  let Ctor = null;
  if (follows) {
    say('installed ver  ' + (follows.libVersion() || '(not installed)'));
    const res = await follows.loadLib();
    if (res.Ctor) { Ctor = res.Ctor; say('loads          yes, via ' + res.how); }
    else if (res.missing) say('loads          NO — it is not installed. The launcher installs it when you pick the Follow Reel.');
    else say('loads          NO — it is installed but will not load: ' + (res.error && res.error.message));
  }

  head('4. CAN IT BE STARTED');
  /* The exact bug that cost a stream: the library's own constructor
     reads a property off an options argument its documentation says is
     optional. Each shape is tried and the result printed, so a future
     version breaking this differently is visible immediately. */
  if (!Ctor) say('skipped — nothing loaded to start');
  else {
    const shapes = [
      ['username + {}', ['probe', {}]],
      ['username only', ['probe']],
    ];
    for (const [why, args] of shapes) {
      try { new Ctor(...args); say((why + ' ').padEnd(15) + 'works'); }
      catch (e) { say((why + ' ').padEnd(15) + 'fails — ' + e.message); }
    }
  }

  head('5. YOUR NAMES');
  const tiktok = readName('your-tiktok-name.txt', true);
  say('tiktok         ' + (tiktok || '(not set)'));
  say('minecraft      ' + readName('your-minecraft-name.txt', false));
  if (tiktok && !/^[A-Za-z0-9._]{2,24}$/.test(tiktok)) {
    say('WARNING: that does not look like a TikTok username.');
  }

  head('6. CAN IT REACH YOUR LIVE ROOM');
  if (!Ctor) say('skipped — nothing loaded');
  else if (!tiktok || tiktok === '(not set)') say('skipped — no TikTok name set');
  else {
    let conn = null;
    try { conn = new Ctor(tiktok, {}); }
    catch (e) { say('could not start it — ' + e.message); }
    if (conn) {
      say('connecting to @' + tiktok + ' …');
      /* A hard stop of its own: a sign server having a bad day must not
         leave somebody staring at a check that never finishes.
         The timer is cleared either way — left running, it holds the
         event loop open and the check sits there for the full
         three-quarters of a minute after it already has its answer,
         which looks exactly like the hang it is meant to prevent. */
      let bell;
      const raced = await Promise.race([
        Promise.resolve(conn.connect()).then(s => ({ ok: true, s })).catch(e => ({ err: (e && e.message) || String(e) })),
        new Promise(r => { bell = setTimeout(() => r({ err: 'no answer within 45 seconds' }), 45000); }),
      ]);
      clearTimeout(bell);
      try { conn.disconnect && conn.disconnect(); } catch {}
      if (raced.ok) {
        say('RESULT         CONNECTED. Follows will reach the reel.');
        say('               room ' + ((raced.s && raced.s.roomId) || '?'));
      } else {
        const m = raced.err || '';
        say('RESULT         did not connect');
        say('reason         ' + m.slice(0, 300));
        if (/offline|not.*live|LIVE has ended|user_not_found|UserOffline/i.test(m)) {
          say('meaning        you are not broadcasting right now. This is NORMAL when you are');
          say('               offline — it listens to a live room, not your profile. Run this');
          say('               again while you are actually live to test properly.');
        } else if (/rate.?limit|429|sign|euler/i.test(m)) {
          say('meaning        the free signing service this depends on is busy or rate limiting.');
          say('               Not your fault and not fixable from here — it usually clears.');
        } else {
          say('meaning        TikTok refused for some other reason. Send this file on.');
        }
      }
    }
  }

  head('7. THE REEL ITSELF');
  const free = await portFree(8094);
  say('port 8094      ' + (free ? 'free — the reel is NOT running right now'
                                : 'in use — something is listening, probably the reel'));
  for (const f of ['wheel-prizes.json', 'wheel-wins.json']) {
    const p = path.join(__dirname, f);
    say((f + ' ').padEnd(18) + (fs.existsSync(p)
      ? tryHard(() => JSON.parse(fs.readFileSync(p, 'utf8')).length + ' entries', 'present but unreadable')
      : 'not there yet (normal on a fresh copy)'));
  }

  head('8. THE WAY IN THAT DOES NOT NEED TIKTOK');
  say('Whatever TikTok is doing, this always works while the reel is open:');
  say('  curl -X POST http://localhost:8094/follow -d "{\\"name\\":\\"someone\\"}"');
  say('or just use the Test button in the control panel.');

  say('');
  say('='.repeat(60));
  say('Saved to: ' + OUT);
  try { fs.writeFileSync(OUT, lines.join('\r\n') + '\r\n'); }
  catch (e) { console.log('(could not save the file — ' + e.message + ')'); }
})();
