#!/usr/bin/env node
/**
 * Session stats — standalone server
 * -------------------------------------------------------------
 * How much you are up or down THIS stream, on screen, in a card small
 * enough to sit in a corner next to whatever game is running.
 *
 * It starts from a balance you type in, then follows the money:
 *   · players paying you            → up
 *   · you paying players            → down
 *   · shop buying and selling       → down / up
 *   · anything it could not read    → corrected the moment you type /bal
 *
 * That last line is the important one. Every server words its shop
 * messages differently, so rather than pretending to know them all, the
 * tracker treats a balance line in chat as the final word: type /bal and
 * whatever it missed is put right and listed as "something else", so the
 * number on screen is never quietly wrong.
 *
 * Runs alongside a game rather than instead of one — its own port, its
 * own link, and it never touches the game's state.
 *
 * LIVE Studio link source:  http://localhost:8096/display
 * Control panel:            http://localhost:8096/
 */
const http = require('http');
const fs   = require('fs');
const path = require('path');
const os   = require('os');

const BUILD = process.env.DONUT_BUILD || '2026-10-04';
const REV = process.env.DONUT_REV ? '  rev ' + process.env.DONUT_REV : '';
const PORT = 8096;

const paylog = require('./paylog');

let WebSocketServer;
try { ({ WebSocketServer } = require('ws')); }
catch { ({ WebSocketServer } = require('./ws-lite')); }

/* Where the session is kept between restarts. A stream does not end
   because a window was closed by accident, and starting the figure again
   from zero mid-stream is worse than useless. */
const SAVE = path.join(os.homedir(), '.donut-session.json');

const S = {
  phase: 'off',           // off | live
  startBal: 0,
  bal: 0,
  inTotal: 0,             // players paying you, and shop sales
  outTotal: 0,            // you paying players, and shop buying
  otherTotal: 0,          // what a /bal correction found that we missed
  events: [],             // newest first: { dir, name, amount, why, at }
  samples: [],            // { at, bal } for the line on the card
  startedAt: 0,
  mode: 'graph',          // graph | plain
  showLast: true,
  uiScale: 1.15,
  cardW: 13,
  unread: [],             // money-ish lines nobody taught us — send them in
};
let ign = process.env.DONUT_IGN || 'mrchicken75';
let dirty = true;

const now = () => Date.now();
const mark = () => { dirty = true; };
const say = t => console.log(`  ${new Date().toLocaleTimeString([], {hour12:false})}  ${t}`);
function money(n){
  const neg = n < 0; n = Math.abs(Math.floor(n || 0));
  const s = n >= 1e12 ? +(n/1e12).toFixed(2) + 'T'
          : n >= 1e9  ? +(n/1e9).toFixed(2) + 'B'
          : n >= 1e6  ? +(n/1e6).toFixed(2) + 'M'
          : n >= 1e3  ? +(n/1e3).toFixed(1) + 'K'
          : String(n);
  return (neg ? '-$' : '$') + s;
}
const net = () => S.bal - S.startBal;

function save(){
  try { fs.writeFileSync(SAVE, JSON.stringify({ ...S, unread: S.unread.slice(0, 20) }), { mode: 0o600 }); }
  catch { /* read-only home — the session still works, it just will not survive a restart */ }
}
function load(){
  try {
    const o = JSON.parse(fs.readFileSync(SAVE, 'utf8'));
    /* Only today's session. Yesterday's figure reappearing on a fresh
       stream is a bug that looks like a lie. */
    if(o && o.startedAt && now() - o.startedAt < 18 * 3600 * 1000) Object.assign(S, o);
  } catch { /* nothing saved yet */ }
}

/* One point every few seconds, and one whenever the balance moves, so
   the line has shape without the array growing all stream. */
const MAX_SAMPLES = 180;
function sample(force){
  const last = S.samples[S.samples.length - 1];
  if(!force && last && now() - last.at < 4000 && last.bal === S.bal) return;
  if(last && last.bal === S.bal && now() - last.at < 4000) return;
  S.samples.push({ at: now(), bal: S.bal });
  while(S.samples.length > MAX_SAMPLES) S.samples.shift();
}

function record(dir, name, amount, why){
  S.events.unshift({ dir, name: name || '', amount, why: why || '', at: now() });
  if(S.events.length > 60) S.events.pop();
}

function begin(startBal){
  S.phase = 'live';
  S.startBal = Math.max(0, Math.floor(Number(startBal) || 0));
  S.bal = S.startBal;
  S.inTotal = 0; S.outTotal = 0; S.otherTotal = 0;
  S.events = []; S.samples = []; S.unread = [];
  S.startedAt = now();
  sample(true);
  say(`session started at ${money(S.startBal)}`);
  mark(); save();
}
function stop(){ S.phase = 'off'; say('session stopped'); mark(); save(); }

function moneyIn(name, amount, why){
  if(S.phase !== 'live' || !(amount > 0)) return;
  S.bal += amount; S.inTotal += amount;
  record('in', name, amount, why);
  say(`+${money(amount)} ${name || why || ''} · ${money(net())} this stream`);
  sample(true); mark(); save();
}
function moneyOut(amount, who, why){
  if(S.phase !== 'live' || !(amount > 0)) return;
  S.bal -= amount; S.outTotal += amount;
  record('out', who, amount, why);
  say(`-${money(amount)} ${who || why || ''} · ${money(net())} this stream`);
  sample(true); mark(); save();
}
/* A balance straight from the game wins over anything we worked out.
   The gap is kept rather than hidden: "something else" on the panel is
   how you find out there is a wording we should be reading. */
function syncBalance(bal){
  if(S.phase !== 'live' || !(bal > 0)) return;
  const diff = bal - S.bal;
  if(diff === 0){ return; }
  S.bal = bal;
  S.otherTotal += diff;
  record('fix', '', Math.abs(diff), diff > 0 ? 'found' : 'missing');
  say(`/bal says ${money(bal)} — adjusted by ${money(diff)} (something we could not read)`);
  sample(true); mark(); save();
}

/* Everything the games already read: a player paying the streamer. */
function onPayment(name, amount){ moneyIn(name, amount, 'paid you'); }

/* And everything they do not. */
function onLine(line){
  if(S.phase !== 'live') return;
  const bal = paylog.parseBalance(line);
  if(bal) return syncBalance(bal.amount);
  const out = paylog.parseSpend(line);
  if(out) return moneyOut(out.amount, out.who, out.why);
  const earn = paylog.parseEarn(line);
  if(earn) return moneyIn('', earn.amount, earn.why);
  /* Money-shaped and about you, but unread. Collected so it can be sent
     in and turned into a pattern rather than disappearing. */
  if(/\byou(r)?\b/i.test(line) && /\b\d[\d.,]*\s*[kmbt]?\b/.test(line) && /[$💲]|\b\d{4,}\b/.test(line)){
    const chat = paylog.clean(line).replace(/^.*?\[CHAT\]\s*/i, '').trim().slice(0, 140);
    if(chat && !S.unread.includes(chat)){
      S.unread.unshift(chat);
      while(S.unread.length > 20) S.unread.pop();
      mark();
    }
  }
}

function handleCmd(c){
  const a = c.args || {};
  switch(c.name){
    case 's.start':  begin(a.startBal); break;
    case 's.stop':   stop(); break;
    case 's.add':    moneyIn('', Math.floor(Number(a.amount) || 0), 'added by hand'); break;
    case 's.take':   moneyOut(Math.floor(Number(a.amount) || 0), '', 'taken by hand'); break;
    case 's.setBal': syncBalance(Math.floor(Number(a.amount) || 0)); break;
    case 's.clearUnread': S.unread = []; mark(); break;
    case 's.config': for(const k of Object.keys(a)) if(k in S) S[k] = a[k];
                     mark(); save(); break;
    case 'config':   if(a.ign){ ign = a.ign; paylog.setIgn(ign); mark(); } break;
  }
}

/* ================= http + websocket ================= */
const PAGE = path.join(__dirname, 'donut-stats.html');
function isLocal(req){
  const ip = (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
  return /^(::1|127\.|192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ip);
}
const server = http.createServer((req, res) => {
  if(!fs.existsSync(PAGE)){
    res.writeHead(404);
    return res.end('donut-stats.html must sit next to this script');
  }
  if(!isLocal(req) && !/^\/(display|overlay)/i.test(req.url || '')){
    res.writeHead(302, { Location: '/display' });
    return res.end();
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  fs.createReadStream(PAGE).pipe(res);
});

const payload = () => ({ t: 'state', m: S, s: { ign }, net: net(), sv: now() });
const snapshot = () => JSON.stringify(payload());

const wss = new WebSocketServer({ server });
const clients = new Set();
wss.on('connection', (ws, req) => {
  const trusted = isLocal(req);
  clients.add(ws);
  ws.send(snapshot());
  ws.on('close', () => clients.delete(ws));
  ws.on('message', raw => {
    if(!trusted) return;
    let m; try { m = JSON.parse(raw.toString()); } catch { return; }
    if(m.t === 'cmd') handleCmd(m);
  });
});
setInterval(() => {
  if(!dirty || clients.size === 0) return;
  dirty = false;
  const s = snapshot();
  for(const c of clients) if(c.readyState === 1) c.send(s);
}, 50);
/* A quiet stream still needs a dot on the line every few seconds, or the
   graph is a flat segment with a gap in the middle. */
setInterval(() => { if(S.phase === 'live'){ sample(); mark(); } }, 5000).unref();

/* ================= start up ================= */
function lanIP(){
  for(const list of Object.values(os.networkInterfaces()))
    for(const n of list || [])
      if(n.family === 'IPv4' && !n.internal) return n.address;
  return null;
}
const PORT_TRIES = [PORT, PORT + 10, PORT + 20, PORT + 30, PORT + 100];
let portAt = 0, livePort = PORT;
server.on('error', err => {
  if (err && err.code === 'EADDRINUSE' && portAt + 1 < PORT_TRIES.length) {
    portAt += 1; livePort = PORT_TRIES[portAt];
    return server.listen(livePort);
  }
  console.log('  session stats could not start: ' + (err && err.message ? err.message : err));
  /* Deliberately not fatal. This runs alongside a game, and a game must
     never fail to start because a side panel could not find a port. */
});

let announced = false;
server.on('listening', () => {
  if(announced) return;
  announced = true;
  const lan = lanIP();
  console.log(`
  Session stats   ·   build ${BUILD}${REV}
    overlay       http://localhost:${livePort}/display
    controls      http://localhost:${livePort}/${lan ? `
    on your phone http://${lan}:${livePort}/` : ''}
`);
  load();
  paylog.setIgn(ign);
  /* Its own tail. The games read the same log in the same process, and
     two readers of one file cost nothing — each gets every line once,
     which is exactly what is wanted here: the game sees payments, this
     sees everything. */
  paylog.startTail({ onPayment, onLine, say: () => {} });
});
server.listen(PORT);

try {
  const uplink = require('./uplink');
  const up = uplink.attach({ getPort: () => livePort, game: 'stats', getPayload: payload });
  setInterval(() => up.push(), 200).unref();
} catch (e) { /* local only */ }

module.exports = { S, begin, stop, moneyIn, moneyOut, syncBalance, onLine, onPayment,
                   handleCmd, net, money, server, sample };
