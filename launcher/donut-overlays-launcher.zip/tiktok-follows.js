/**
 * Follows out of a TikTok live room
 * -------------------------------------------------------------
 * Every word of this file exists because TikTok has no supported way to
 * tell a program that somebody followed you. What people use instead is
 * an unofficial library that reads the same feed the web player reads.
 * It works. It also breaks, without warning, whenever TikTok changes
 * something on their side.
 *
 * WHY THIS FILE WAS REWRITTEN
 * ---------------------------
 * The first version loaded the library with require(). That is wrong,
 * and wrong in the most misleading way possible.
 *
 * tiktok-live-connector v2 ships as an ES module ("type": "module" in
 * its package.json). require() cannot load one of those: it throws
 * ERR_REQUIRE_ESM. The old code caught the throw and treated ANY
 * failure as "the library is not installed" — so a streamer who HAD
 * installed it correctly was told to install it, did it again, and got
 * the same message forever. Nothing on screen ever pointed at the real
 * cause, which is why this sat broken through a live stream.
 *
 * So now:
 *   · the library is loaded with dynamic import(), which reads both the
 *     old CommonJS v1 and the new ESM v2.
 *   · "not installed" and "installed but would not load" are told apart
 *     and say different things, because they need different answers.
 *   · the Node version is checked up front — v2 needs Node 20, and a
 *     PC on Node 18 fails with a message about syntax that nobody could
 *     be expected to decode.
 *   · every failure is said out loud, in words, with what to do. A
 *     listener that silently stops is worse than one that was never
 *     there, because the streamer carries on expecting spins.
 *   · reconnects back off instead of hammering. Being rate limited for
 *     reconnecting too fast is a self-inflicted outage.
 *
 * The launcher installs the library for the streamer, so under normal
 * use none of the failure paths below are ever reached. They exist for
 * the PC where the install could not run.
 */
const path = require('path');
const { pathToFileURL } = require('url');

const NEED_NODE = 20;

function nodeMajor(){
  const m = /^v?(\d+)/.exec(process.version || '');
  return m ? Number(m[1]) : 0;
}

/**
 * Find the connector class, whichever shape it is published in.
 *
 * Three attempts, cheapest first:
 *   1. require()      — v1, plain CommonJS.
 *   2. import()       — v2, an ES module. This is the one that matters.
 *   3. import() of the package's own folder, by absolute path, for the
 *      case where the launcher folder is not where Node started and the
 *      bare name does not resolve.
 *
 * Returns { Ctor, how } on success, or { error, missing } on failure,
 * where `missing` is true only when the package genuinely is not there.
 */
async function loadLib(){
  const pick = mod => {
    if(!mod) return null;
    /* An ES module namespace, a CommonJS export object, and a namespace
       whose real contents sit under .default are all possible, and which
       one you get depends on the version AND on how Node was asked to
       load it. Look in all three rather than betting on one. */
    const boxes = [mod, mod.default].filter(Boolean);
    for(const box of boxes){
      const C = box.TikTokLiveConnection || box.WebcastPushConnection;
      if(typeof C === 'function') return C;
    }
    return null;
  };

  let notFound = true;
  let lastError = null;

  /* 1. CommonJS. Silently skipped for v2, which throws ERR_REQUIRE_ESM. */
  try {
    const C = pick(require('tiktok-live-connector'));
    if(C) return { Ctor: C, how: 'require' };
  } catch(e){
    if(e && e.code !== 'MODULE_NOT_FOUND') { notFound = false; lastError = e; }
  }

  /* 2. The real path for v2. */
  try {
    const C = pick(await import('tiktok-live-connector'));
    if(C) return { Ctor: C, how: 'import' };
    notFound = false;
    lastError = new Error('the library loaded but has no connection class in it');
  } catch(e){
    if(e && (e.code === 'ERR_MODULE_NOT_FOUND' || e.code === 'MODULE_NOT_FOUND')){
      /* Genuinely absent — leave notFound alone. */
    } else { notFound = false; lastError = e; }
  }

  /* 3. By absolute path, next to this file. Node resolves a bare name
        against the CURRENT WORKING DIRECTORY's node_modules as well as
        the file's, and a shortcut started somewhere else has bitten
        people before. Cheap to rule out. */
  try {
    const here = path.join(__dirname, 'node_modules', 'tiktok-live-connector', 'package.json');
    const pkg = require(here);
    const entry = path.join(path.dirname(here), pkg.main || 'index.js');
    const C = pick(await import(pathToFileURL(entry).href));
    if(C) return { Ctor: C, how: 'folder' };
  } catch(e){
    if(e && e.code !== 'MODULE_NOT_FOUND') { notFound = false; lastError = lastError || e; }
  }

  if(notFound) return { missing: true, error: null };
  return { missing: false, error: lastError || new Error('unknown load failure') };
}

/* Installed version, for the log. Purely so a screenshot of the window
   is enough to tell which library is in play when TikTok next changes
   something. Never throws. */
function libVersion(){
  try { return require(path.join(__dirname, 'node_modules', 'tiktok-live-connector', 'package.json')).version || ''; }
  catch { try { return require('tiktok-live-connector/package.json').version || ''; } catch { return ''; } }
}

/**
 * @param {string}   user      the TikTok username, no @
 * @param {function} onFollow  called with the follower's name
 * @param {function} say       prints into the game's own log
 * @param {function} onState   ('tiktok' | 'http', sentence) — what the panel shows
 */
function start({ user, onFollow, say, onState }){
  let conn = null, stopped = false, tries = 0, timer = null;

  /* Back off hard. A room that is simply not live yet refuses every
     attempt, and trying once a second for an hour is how an account
     gets rate limited for the evening. */
  const waitFor = () => Math.min(60000, 4000 * Math.pow(1.7, Math.min(tries, 6)));

  function retry(){
    if(stopped || timer) return;
    timer = setTimeout(() => { timer = null; connect(); }, waitFor());
    if(timer.unref) timer.unref();
  }

  function connect(){
    if(stopped || !Ctor) return;
    try { conn = new Ctor(user); }
    catch(e){
      say('follows: could not start the TikTok listener — ' + e.message);
      onState('http', 'The TikTok listener would not start: ' + e.message.slice(0, 90));
      tries++; retry();
      return;
    }

    /* Both spellings, because the library has used both depending on
       version, and a rename must not silently stop every spin. In v2
       'follow' is its own event; in v1 it also arrived inside 'social'
       alongside shares. */
    for(const ev of ['follow', 'social']){
      try {
        conn.on(ev, data => {
          if(!data) return;
          /* 'social' covers follows AND shares; only the follow half is a
             spin. Shares firing the reel would hand out dares to people
             who never followed, which is the exact thing the streamer
             promised on screen. */
          if(ev === 'social'){
            const label = String(data.displayType || data.label || '');
            if(!/follow/i.test(label)) return;
          }
          /* v1 put the name at the top level; v2 nests it under .user.
             Read both rather than picking a version to be right about. */
          const u = data.user || {};
          const name = data.uniqueId || u.uniqueId || data.nickname || u.nickname;
          if(name) onFollow(String(name));
        });
      } catch { /* older or newer builds may not know this event */ }
    }

    try {
      conn.on('disconnected', () => {
        if(stopped) return;
        say('follows: TikTok dropped the connection — reconnecting');
        onState('http', 'TikTok dropped the connection. Reconnecting on its own.');
        tries++; retry();
      });
      /* Errors are reported through the connect() rejection and the
         disconnect handler. Swallowing them here only stops Node
         treating an unhandled "error" event as fatal. */
      conn.on('error', () => {});
    } catch { /* not every version emits these */ }

    Promise.resolve(conn.connect()).then(() => {
      tries = 0;
      say(`follows: listening to @${user} on TikTok`);
      onState('tiktok', 'Listening to @' + user + ' on TikTok. A follow will spin the reel '
        + 'within a second or so.');
    }).catch(err => {
      tries++;
      const msg = (err && err.message) || String(err);
      /* The overwhelmingly common case, and worth its own words: they
         are simply not live yet. Saying "connection failed" for that
         sends people hunting for a fault that is not there. */
      if(/offline|not.*live|LIVE has ended|user_not_found|UserOfflineError/i.test(msg)){
        if(tries === 1) say(`follows: @${user} is not live yet — will keep checking`);
        onState('http', '@' + user + ' is not live on TikTok right now. This listens to a live '
          + 'ROOM, not your profile, so nothing arrives until you are actually broadcasting. '
          + 'It keeps checking on its own.');
      } else if(/rate.?limit|429|sign|euler/i.test(msg)){
        say('follows: TikTok\'s signing service is rate limiting us — backing off');
        onState('http', 'The free signing service this uses is busy right now (it is shared, '
          + 'and it rate limits). It keeps retrying — this usually clears on its own.');
      } else {
        say('follows: TikTok would not connect — ' + msg.slice(0, 120));
        onState('http', 'TikTok refused the connection: ' + msg.slice(0, 90)
          + '. Everything else still works — a follow can be sent to POST /follow by anything.');
        if(tries === 1){
          say('         if this keeps up, TikTok has probably changed something.');
          say('         Everything still works: send follows to  POST /follow  instead.');
        }
      }
      retry();
    });
  }

  /* ---- load, then connect ----
     The handle is returned straight away and the library is loaded in
     the background, because loading is now asynchronous and the relay
     must not sit waiting on it before it will serve a page. */
  let Ctor = null;

  if(nodeMajor() && nodeMajor() < NEED_NODE){
    say(`follows: this PC is on Node ${process.version} and the TikTok listener needs Node ${NEED_NODE} or newer.`);
    say('         install the current version from https://nodejs.org, then start this again.');
    onState('http', 'This PC has Node ' + process.version + '. The TikTok listener needs Node '
      + NEED_NODE + ' or newer. Install the current version from nodejs.org and start this window '
      + 'again — everything else works meanwhile.');
    return { stop(){} };
  }

  loadLib().then(res => {
    if(stopped) return;
    if(res.Ctor){
      const v = libVersion();
      say('follows: TikTok listener loaded' + (v ? ' (v' + v + ')' : '') + ` — watching @${user}`);
      Ctor = res.Ctor;
      connect();
      return;
    }
    if(res.missing){
      say('follows: the TikTok listener is not installed on this PC.');
      say('         run  npm install tiktok-live-connector  in this folder,');
      say('         then start this window again. Everything else works meanwhile.');
      onState('http', 'The TikTok listener is not installed on this PC. Run '
        + 'npm install tiktok-live-connector in the launcher folder, then start this window again.');
      return;
    }
    /* Installed, but would not load. Telling somebody to install it
       again here is what wasted a whole stream last time. */
    const msg = (res.error && res.error.message) || 'unknown error';
    say('follows: the TikTok listener IS installed but would not load —');
    say('         ' + msg.slice(0, 160));
    say('         installing it again will not help. Deleting the node_modules folder');
    say('         and letting the launcher reinstall it usually does.');
    onState('http', 'The TikTok listener is installed but would not load: ' + msg.slice(0, 110)
      + ' — installing it again will not help. Delete the node_modules folder next to the '
      + 'launcher and start it again so it reinstalls cleanly.');
  }).catch(e => {
    if(stopped) return;
    say('follows: could not load the TikTok listener — ' + e.message);
    onState('http', 'Could not load the TikTok listener: ' + String(e.message).slice(0, 100));
  });

  return {
    stop(){
      stopped = true;
      if(timer) clearTimeout(timer);
      try { conn && conn.disconnect && conn.disconnect(); } catch { /* already gone */ }
    },
  };
}

module.exports = { start, loadLib, libVersion, NEED_NODE };
