/**
 * Donut Overlays — the launcher updates itself
 * ---------------------------------------------------------------
 * What this replaces: download the zip again, delete the old folder,
 * extract the new one, and put your own files back. Several times a
 * day, on a bad day. Most people simply did not, so fixes did not
 * reach the people who had reported the fault.
 *
 * Now the launcher asks the site what the current files are, fetches
 * only the ones that differ, and restarts into them.
 *
 * The rules it follows, and why each one is there:
 *
 *   NOTHING THE CUSTOMER MADE IS EVER TOUCHED. Only files that came
 *   out of the zip are considered. your-minecraft-name.txt,
 *   your-tiktok-name.txt, wheel-prizes.json, wheel-wins.json and the
 *   node_modules folder are not in the zip, so they cannot be
 *   overwritten and cannot be deleted. Nothing here deletes anything,
 *   ever — a bad manifest should at worst do nothing.
 *
 *   ALL OR NOTHING. Every file is downloaded and checked against its
 *   hash BEFORE the first one is moved into place. A connection that
 *   dies half way through leaves the folder exactly as it was, rather
 *   than a launcher from today running an overlay page from last week.
 *
 *   THE STARTER FILE IS LEFT ALONE. cmd.exe reads a .bat by byte
 *   offset as it runs it, so rewriting the one currently executing
 *   makes it jump into the middle of a line. It is saved beside the
 *   original instead and mentioned once.
 *
 *   IT IS NEVER THE REASON A STREAM DOES NOT START. No network, site
 *   down, old site that has never heard of updates, corrupt reply,
 *   read-only folder — all of them end the same way: one quiet line
 *   and the launcher carries on with the files it already has.
 */
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');

const SITE = process.env.DONUT_SITE || 'https://donutoverlays.com';
const CONF = path.join(os.homedir(), '.donut-overlays.json');

/* Whole check budget. Long enough for a slow phone tether, short enough
   that a site which is up but wedged does not hold up a stream. */
const ASK_MS = 8000;
const FILE_MS = 60000;

/* The same shape the server enforces. Checked again here because the
   reply comes off the network, and "the server would never send that"
   is not a thing worth betting a customer's folder on. */
const SAFE_NAME = /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,59}$/;

function savedToken(){
  try { return JSON.parse(fs.readFileSync(CONF, 'utf8')).token || ''; }
  catch { return ''; }
}

function sha256(file){
  try { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
  catch { return ''; }   // missing counts as different, which is right
}

async function get(url, ms){
  const stop = new AbortController();
  const t = setTimeout(() => stop.abort(), ms);
  if(t.unref) t.unref();
  try {
    const r = await fetch(url, { signal: stop.signal, headers: { 'cache-control': 'no-cache' } });
    if(!r.ok) throw new Error('the site said ' + r.status);
    return r;
  } finally { clearTimeout(t); }
}

/**
 * Bring the folder up to date.
 *
 * @param {function} say  where to print progress
 * @returns {Promise<null | {changed:string[], build:string, fragile:string[]}>}
 *          null when there was nothing to do or nothing could be done.
 */
async function apply(say = console.log){
  if(process.env.DONUT_NO_UPDATE === '1') return null;

  const token = savedToken();
  /* No saved login means this is a first run, straight out of a zip
     that was downloaded minutes ago. There is nothing to update to, and
     asking would only mean a pause before the sign-in prompt. */
  if(!token) return null;

  let feed;
  try {
    const r = await get(SITE + '/update/' + encodeURIComponent(token) + '/manifest.json', ASK_MS);
    feed = await r.json();
  } catch {
    /* Offline, or a site that predates this. Both are ordinary. */
    return null;
  }
  if(!feed || !Array.isArray(feed.files) || !feed.files.length) return null;

  /* What differs. Hashing eighteen files is a few milliseconds and is
     the only comparison that cannot be fooled by a clock, a version
     string somebody forgot to bump, or a half-finished extract. */
  const want = [];
  const fragile = [];
  for(const f of feed.files){
    if(!f || !SAFE_NAME.test(String(f.name || ''))) continue;
    if(typeof f.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(f.sha256)) continue;
    const here = path.join(__dirname, f.name);
    if(sha256(here) === f.sha256) continue;
    if(f.replaceWhileRunning === false){ fragile.push(f.name); continue; }
    want.push(f);
  }

  if(!want.length){
    return fragile.length ? { changed: [], build: feed.build || '', fragile } : null;
  }

  say('');
  say('  Updating to build ' + (feed.build || '?') + ' — ' + want.length
    + (want.length === 1 ? ' file' : ' files') + ' to fetch.');

  /* Stage 1: fetch and verify everything, touching nothing real. */
  const staged = [];
  try {
    for(const f of want){
      const r = await get(
        SITE + '/update/' + encodeURIComponent(token) + '/f/' + encodeURIComponent(f.name), FILE_MS);
      const body = Buffer.from(await r.arrayBuffer());
      const got = crypto.createHash('sha256').update(body).digest('hex');
      if(got !== f.sha256) throw new Error(f.name + ' arrived damaged');
      const part = path.join(__dirname, f.name + '.donut-part');
      fs.writeFileSync(part, body);
      staged.push({ part, real: path.join(__dirname, f.name), name: f.name });
    }
  } catch(err){
    for(const s of staged) { try { fs.unlinkSync(s.part); } catch {} }
    say('  Update did not finish (' + err.message + ') — carrying on with what is already here.');
    say('');
    return null;
  }

  /* Stage 2: move them in. Renaming within the same folder is as close
     to instant as this gets, so the window where the folder is half one
     build and half another is microseconds rather than a download. */
  const changed = [];
  for(const s of staged){
    try { fs.renameSync(s.part, s.real); changed.push(s.name); }
    catch(err){
      /* A folder in Program Files, or an antivirus holding a handle.
         What is already swapped stays swapped — every file is
         self-contained and the next start finishes the job. */
      try { fs.unlinkSync(s.part); } catch {}
      say('  Could not replace ' + s.name + ' (' + err.message + ').');
    }
  }

  if(!changed.length){ say(''); return null; }
  say('  Updated ' + changed.length + (changed.length === 1 ? ' file.' : ' files.'));
  say('');
  return { changed, build: feed.build || '', fragile };
}

module.exports = { apply, SAFE_NAME };
