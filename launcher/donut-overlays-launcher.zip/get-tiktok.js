/**
 * Fetching the TikTok listener, so nobody has to
 * -------------------------------------------------------------
 * The Follow Reel needs one thing the launcher does not ship: an
 * unofficial library that reads a TikTok live room. It cannot be bundled
 * — it has its own dependency tree, it is updated whenever TikTok
 * changes something, and pinning a copy inside the zip would mean every
 * customer running whatever version happened to be current on the day
 * the zip was built.
 *
 * So it is fetched. The part that matters is WHO does the fetching.
 * Telling customers to "open a terminal in the launcher folder and run
 * npm install tiktok-live-connector" is a step almost nobody completes,
 * and the one person who did complete it still got told it had not
 * worked, because of a separate bug in how it was being loaded. A setup
 * step that is skipped by most people and misreported for the rest is
 * not a setup step, it is an outage with instructions attached.
 *
 * This runs it for them, once, and says plainly what is happening.
 *
 * Deliberate choices:
 *   · --no-save. package.json stays byte-identical to the one in the
 *     zip, so the self-updater never sees a local edit to fight with.
 *   · a hard time limit. A stalled npm must not hold a stream hostage.
 *   · failure is not fatal, ever. Everything except automatic follows
 *     still works, and POST /follow still accepts them from anything.
 */
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const PKG = 'tiktok-live-connector';
const LIMIT_MS = 4 * 60 * 1000;
const WIN = process.platform === 'win32';
const ARGS = ['install', PKG, '--no-save', '--no-audit', '--no-fund', '--loglevel=error'];

/* How to start npm without a shell.
  
   On Windows npm is a .cmd shim, which CreateProcess cannot run
   directly, so the obvious answer is { shell: true }. Node 22 prints a
   deprecation warning about that — six lines about "security
   vulnerabilities" — into the middle of the streamer's setup window.
   The warning does not apply here (every argument above is a fixed
   string; nothing from the streamer, the network or a file goes into
   it), but a customer reading a security warning while setting up an
   overlay has no way to know that, and "ignore the scary bit" is not
   something a piece of software gets to ask of somebody.
  
   npm is itself a Node program, so the shim can be skipped: run its
   entry script with the Node that is already running this. No shell, no
   warning, and one fewer thing between us and the install. The shim is
   still there as a fallback for a PC where npm lives somewhere else. */
function npmScript(){
  const here = path.dirname(process.execPath);
  for(const p of [
    path.join(here, 'node_modules', 'npm', 'bin', 'npm-cli.js'),          // Windows
    path.join(here, '..', 'lib', 'node_modules', 'npm', 'bin', 'npm-cli.js'), // Linux/macOS
  ]){
    try { if(fs.existsSync(p)) return p; } catch { /* unreadable — try the next */ }
  }
  return null;
}

function run(say){
  return new Promise(resolve => {
    let child;
    const script = npmScript();
    try {
      child = script
        ? spawn(process.execPath, [script, ...ARGS], { cwd: __dirname, windowsHide: true })
        : spawn(WIN ? 'npm.cmd' : 'npm', ARGS, { cwd: __dirname, shell: WIN, windowsHide: true });
    } catch (e) {
      return resolve({ ok: false, why: 'npm would not start (' + e.message + ')' });
    }

    let tail = '';
    const keep = d => { tail = (tail + d.toString()).slice(-600); };
    child.stdout && child.stdout.on('data', keep);
    child.stderr && child.stderr.on('data', keep);

    const timer = setTimeout(() => {
      try { child.kill(); } catch {}
      resolve({ ok: false, why: 'it took longer than four minutes and was stopped' });
    }, LIMIT_MS);
    if (timer.unref) timer.unref();

    child.on('error', e => {
      clearTimeout(timer);
      /* ENOENT here means Node is installed but npm is not on the PATH,
         which happens with some portable Node setups. Worth its own
         wording — "npm failed" would send somebody to the wrong place. */
      resolve({ ok: false, why: e.code === 'ENOENT'
        ? 'npm is not on this PC. It normally comes with Node.js — reinstalling Node from nodejs.org adds it.'
        : 'npm would not run (' + e.message + ')' });
    });

    child.on('close', code => {
      clearTimeout(timer);
      if (code === 0) return resolve({ ok: true });
      const why = tail.trim().split('\n').filter(Boolean).slice(-2).join(' ').slice(0, 200);
      resolve({ ok: false, why: why || ('npm stopped with code ' + code) });
    });
  });
}

/**
 * Make sure the listener is there, installing it if it is not.
 * Never throws and never blocks longer than the limit above.
 *
 * @param {function} say  where to print progress
 * @returns {Promise<boolean>} whether the library can now be loaded
 */
async function ensure(say = console.log) {
  let follows;
  try { follows = require('./tiktok-follows'); }
  catch { return false; }

  if (process.env.DONUT_NO_INSTALL === '1') return false;

  /* Ask the same loader the reel itself uses, so this can never say
     "installed" about something the reel then cannot load. That exact
     disagreement is what made the last version so hard to diagnose. */
  let res = await follows.loadLib();
  if (res.Ctor) return true;

  if (!res.missing) {
    /* There, but broken. Reinstalling on top rarely fixes that and
       would cost four minutes before every stream. Leave it to
       tiktok-follows.js to explain. */
    return false;
  }

  say('');
  say('  The Follow Reel needs one extra piece to read follows from TikTok.');
  say('  Fetching it now — this happens once, and takes a minute or two.');
  say('');

  const out = await run(say);
  if (!out.ok) {
    say('  Could not fetch it: ' + out.why);
    say('');
    say('  The reel still works. It just will not pick up follows by itself —');
    say('  you can still send one from the control panel to test everything.');
    say('');
    return false;
  }

  res = await follows.loadLib();
  if (res.Ctor) {
    say('  Done — follows will come in on their own from now on.');
    say('');
    return true;
  }
  /* Installed cleanly and still will not load. Almost always a Node
     that is too old for it. Saying so beats another install attempt. */
  say('  It installed, but will not load on this PC'
    + (res.error ? ' (' + String(res.error.message).slice(0, 120) + ')' : '') + '.');
  say('  Node ' + follows.NEED_NODE + ' or newer is needed — this PC has ' + process.version + '.');
  say('');
  return false;
}

module.exports = { ensure, PKG };
