/**
 * Fetching the TikTok listener, so nobody has to
 * -------------------------------------------------------------
 * The Follow Reel needs one thing the launcher does not ship: an
 * unofficial library that reads a TikTok live room. It cannot be bundled
 * — it has its own dependency tree, it is updated whenever TikTok
 * changes something, and pinning a copy inside the zip would mean every
 * customer running whatever version happened to be current on the day
 * the zip was built.
 *
 * So it is fetched. The part that matters is WHO does the fetching.
 * Telling customers to "open a terminal in the launcher folder and run
 * npm install tiktok-live-connector" is a step almost nobody completes,
 * and the one person who did complete it still got told it had not
 * worked, because of a separate bug in how it was being loaded. A setup
 * step that is skipped by most people and misreported for the rest is
 * not a setup step, it is an outage with instructions attached.
 *
 * This runs it for them, once, and says plainly what is happening.
 *
 * Deliberate choices:
 *   · --no-save. package.json stays byte-identical to the one in the
 *     zip, so the self-updater never sees a local edit to fight with.
 *   · a hard time limit. A stalled npm must not hold a stream hostage.
 *   · failure is not fatal, ever. Everything except automatic follows
 *     still works, and POST /follow still accepts them from anything.
 */
const { spawn } = require('child_process');
const path = require('path');

const PKG = 'tiktok-live-connector';
const LIMIT_MS = 4 * 60 * 1000;

/* npm is a .cmd shim on Windows, which CreateProcess will not run
   directly. Going through the shell is the supported way to invoke it,
   and the arguments here are all fixed strings — nothing from the
   streamer, the network or a file is interpolated into this command. */
const WIN = process.platform === 'win32';

function run(say){
  return new Promise(resolve => {
    let child;
    try {
      child = spawn(WIN ? 'npm.cmd' : 'npm',
        ['install', PKG, '--no-save', '--no-audit', '--no-fund', '--loglevel=error'],
        { cwd: __dirname, shell: WIN, windowsHide: true });
    } catch (e) {
      return resolve({ ok: false, why: 'npm would not start (' + e.message + ')' });
    }

    let tail = '';
    const keep = d => { tail = (tail + d.toString()).slice(-600); };
    child.stdout && child.stdout.on('data', keep);
    child.stderr && child.stderr.on('data', keep);

    const timer = setTimeout(() => {
      try { child.kill(); } catch {}
      resolve({ ok: false, why: 'it took longer than four minutes and was stopped' });
    }, LIMIT_MS);
    if (timer.unref) timer.unref();

    child.on('error', e => {
      clearTimeout(timer);
      /* ENOENT here means Node is installed but npm is not on the PATH,
         which happens with some portable Node setups. Worth its own
         wording — "npm failed" would send somebody to the wrong place. */
      resolve({ ok: false, why: e.code === 'ENOENT'
        ? 'npm is not on this PC. It normally comes with Node.js — reinstalling Node from nodejs.org adds it.'
        : 'npm would not run (' + e.message + ')' });
    });

    child.on('close', code => {
      clearTimeout(timer);
      if (code === 0) return resolve({ ok: true });
      const why = tail.trim().split('\n').filter(Boolean).slice(-2).join(' ').slice(0, 200);
      resolve({ ok: false, why: why || ('npm stopped with code ' + code) });
    });
  });
}

/**
 * Make sure the listener is there, installing it if it is not.
 * Never throws and never blocks longer than the limit above.
 *
 * @param {function} say  where to print progress
 * @returns {Promise<boolean>} whether the library can now be loaded
 */
async function ensure(say = console.log) {
  let follows;
  try { follows = require('./tiktok-follows'); }
  catch { return false; }

  if (process.env.DONUT_NO_INSTALL === '1') return false;

  /* Ask the same loader the reel itself uses, so this can never say
     "installed" about something the reel then cannot load. That exact
     disagreement is what made the last version so hard to diagnose. */
  let res = await follows.loadLib();
  if (res.Ctor) return true;

  if (!res.missing) {
    /* There, but broken. Reinstalling on top rarely fixes that and
       would cost four minutes before every stream. Leave it to
       tiktok-follows.js to explain. */
    return false;
  }

  say('');
  say('  The Follow Reel needs one extra piece to read follows from TikTok.');
  say('  Fetching it now — this happens once, and takes a minute or two.');
  say('');

  const out = await run(say);
  if (!out.ok) {
    say('  Could not fetch it: ' + out.why);
    say('');
    say('  The reel still works. It just will not pick up follows by itself —');
    say('  you can still send one from the control panel to test everything.');
    say('');
    return false;
  }

  res = await follows.loadLib();
  if (res.Ctor) {
    say('  Done — follows will come in on their own from now on.');
    say('');
    return true;
  }
  /* Installed cleanly and still will not load. Almost always a Node
     that is too old for it. Saying so beats another install attempt. */
  say('  It installed, but will not load on this PC'
    + (res.error ? ' (' + String(res.error.message).slice(0, 120) + ')' : '') + '.');
  say('  Node ' + follows.NEED_NODE + ' or newer is needed — this PC has ' + process.version + '.');
  say('');
  return false;
}

module.exports = { ensure, PKG };
