#!/usr/bin/env node
/**
 * Hold the Crown — standalone server
 * -------------------------------------------------------------
 * One crown. Paying the minimum takes it off whoever is wearing it, and
 * a clock counts how long each person has worn it ACROSS the whole
 * round. First person whose total reaches the target wins the pot.
 *
 * Why it plays well: time is what wins, not money. Taking the crown
 * early and cheap while the room is quiet is worth more than one huge
 * payment at the end, so there is a reason to pay at every moment of
 * the round rather than only in the last ten seconds. And nothing is
 * ever decided by chance — the only thing that decides it is who held
 * it longest, which everybody can see adding up on screen.
 *
 * The rules, in full:
 *   · a payment of at least the minimum takes the crown, whatever the
 *     amount — it is a minimum, not an auction. Paying ten times the
 *     minimum buys exactly the same thing.
 *   · the holder's clock runs while they wear it and stops the moment
 *     somebody takes it. It never resets: their next turn adds on top.
 *   · every payment goes into the pot, and the pot pays out what is on
 *     screen — your cut is taken off before the number is shown.
 *   · a payment under the minimum takes nothing. It stays yours, and it
 *     is listed with a Give back button so you can return it if you
 *     would rather.
 *   · paying again while already wearing the crown changes nothing
 *     except the pot. The clock keeps running; it does not restart.
 *
 * Run:    node donut-crown-relay.js
 *         node donut-crown-relay.js --learn        (find your pay message)
 *         node donut-crown-relay.js --test "line"  (check a pattern)
 *
 * LIVE Studio link source:  http://localhost:8095/display
 * Control panel:            http://localhost:8095/
 */

const http = require('http');
const fs   = require('fs');
const path = require('path');
const os   = require('os');

/* The launcher sets DONUT_BUILD, and that is the number that matters:
   it is the one the website records and the one the updater works
   against. The constant below is only a fallback for running this file
   on its own. */
const BUILD = process.env.DONUT_BUILD || '2026-09-22';
const REV = process.env.DONUT_REV ? '  rev ' + process.env.DONUT_REV : '';
const PORT = 8095;

/* ================= pay-message parsing =================
   Shared with every other game, so a fix to a pay-message pattern is a
   fix for all of them at once. */
const paylog = require('./paylog');
const { parseLine } = paylog;

/* ---------- one-off modes ---------- */
const argTest = process.argv.indexOf('--test');
if(argTest > -1){
  console.log(parseLine(process.argv[argTest + 1] || '') || 'no match — add a pattern for this line');
  process.exit(0);
}
const LEARN = process.argv.includes('--learn');

let WebSocketServer;
try { ({ WebSocketServer } = require('ws')); }
catch { ({ WebSocketServer } = require('./ws-lite')); }

/* ================= the round ================= */
const C = {
  phase: 'idle',          // idle | live | done
  seed: 0,                // what you put in to start the pot
  minPay: 1000000,        // flat price to take the crown. Never changes mid-round.
  cutPct: 0,              // your slice of the pot
  targetSec: 120,         // total time on the crown needed to win
  shortToPot: true,       // under-minimum payments swell the pot (off = you keep them)
  pot: 0,
  holder: null,           // { name, since, amount, prev }
  held: {},               // name -> banked milliseconds, NOT counting the current run
  firstAt: {},            // name -> when they first took it (tie-break on an early end)
  pays: [],               // newest first: { id, name, amount, at, took }
  shorts: [],             // newest first: { id, name, amount, at, why, back }
  givenBack: 0,
  kept: 0,                // short payments you kept out of the pot
  steals: 0,
  winner: null,           // { name, ms }
  paused: false,
  vouches: 6,
  uiScale: 1.15,
  layout: 'compact',
  cardW: 19,
};
let ign = process.env.DONUT_IGN || 'mrchicken75';
let dirty = true;
let nextId = 1;

const now = () => Date.now();
const mark = () => { dirty = true; };
const say = t => console.log(`  ${new Date().toLocaleTimeString([], {hour12:false})}  ${t}`);
function money(n){
  n = Math.floor(n || 0);
  if(n >= 1e9) return '$' + +(n/1e9).toFixed(2) + 'B';
  if(n >= 1e6) return '$' + +(n/1e6).toFixed(2) + 'M';
  if(n >= 1e3) return '$' + +(n/1e3).toFixed(1) + 'K';
  return '$' + n;
}
const secs = ms => {
  const s = Math.max(0, Math.round(ms / 1000));
  return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
};
const payout  = () => Math.floor(C.pot * (100 - C.cutPct) / 100);
const yourCut = () => C.pot - payout() + C.kept;

/* Total time someone has worn it: what is banked, plus the run they are
   in the middle of. The running part is computed rather than stored so
   the number on screen is never a tick behind the truth. */
function heldMs(name){
  let ms = C.held[name] || 0;
  if(C.holder && C.holder.name === name && C.phase === 'live' && !C.paused){
    ms += Math.max(0, now() - C.holder.since);
  }
  return ms;
}
/* Stop the current holder's clock and put the time in the bank. Called
   before anything that changes who is holding it, or that stops time
   passing at all. Doing it any other way loses the part-second between
   the last tick and the change. */
function bank(){
  if(!C.holder) return;
  if(C.phase !== 'live' || C.paused) return;
  C.held[C.holder.name] = (C.held[C.holder.name] || 0) + Math.max(0, now() - C.holder.since);
  C.holder.since = now();
}
/* Everyone who has worn it, longest first. Ties go to whoever got there
   first, because on an early end the person who was in front for most of
   the round should not lose to somebody who drew level in the last
   second. */
function standings(){
  const names = new Set(Object.keys(C.held));
  if(C.holder) names.add(C.holder.name);
  return [...names]
    .map(name => ({ name, ms: heldMs(name), firstAt: C.firstAt[name] || 0 }))
    .sort((a, b) => b.ms - a.ms || a.firstAt - b.firstAt);
}

function cOpen(o){
  o = o || {};
  if(o.seed != null) C.seed = o.seed;
  if(o.minPay != null) C.minPay = o.minPay;
  if(o.cutPct != null) C.cutPct = o.cutPct;
  if(o.targetSec) C.targetSec = o.targetSec;
  C.phase = 'live';
  C.pot = C.seed;
  C.holder = null; C.held = {}; C.firstAt = {};
  C.pays = []; C.shorts = []; C.givenBack = 0; C.kept = 0;
  C.steals = 0; C.winner = null; C.paused = false;
  say(`round open · pot ${money(C.pot)} · ${money(C.minPay)} takes the crown · ${secs(C.targetSec*1000)} on it wins`);
  mark();
}

function cPay(name, amount){
  name = String(name || '').trim().replace(/[^A-Za-z0-9_]/g, '').slice(0, 16);
  amount = Math.floor(Number(amount) || 0);
  if(!name || amount <= 0) return;

  /* Outside a live round nothing can be bought. The money is still
     yours; it is listed so you can give it back if you would rather. */
  if(C.phase !== 'live'){
    C.shorts.unshift({ id: nextId++, name, amount, at: now(), why: 'no round running', back: false });
    if(C.shorts.length > 40) C.shorts.pop();
    C.kept += amount;
    say(`NO ROUND  ${name} ${money(amount)} — nothing running, kept for you`);
    return mark();
  }

  /* Under the minimum buys nothing. It does not take the crown and it
     does not touch anybody's clock — otherwise a stream of tiny
     payments would be a way to keep somebody off the crown for free. */
  if(amount < C.minPay){
    C.shorts.unshift({ id: nextId++, name, amount, at: now(), why: 'under the minimum', back: false });
    if(C.shorts.length > 40) C.shorts.pop();
    if(C.shortToPot) C.pot += amount; else C.kept += amount;
    say(`TOO SMALL  ${name} ${money(amount)} — needs ${money(C.minPay)} to take the crown`);
    return mark();
  }

  C.pot += amount;
  const id = nextId++;

  /* Paying while already wearing it. The pot grows and that is all: the
     clock is not touched, because a payment that bought nothing new
     should not be able to cost the payer their own running time — and
     it cannot buy extra either, or the crown would go to whoever pays
     most, which is the money game, not this one. */
  if(C.holder && C.holder.name === name){
    C.pays.unshift({ id, name, amount, at: now(), took: false, topup: true });
    if(C.pays.length > 40) C.pays.pop();
    say(`TOPPED UP  ${name} ${money(amount)} — already holding it, clock untouched · pot ${money(C.pot)}`);
    return mark();
  }

  bank();
  const from = C.holder;
  C.pays.unshift({ id, name, amount, at: now(), took: true, topup: false });
  if(C.pays.length > 40) C.pays.pop();
  C.holder = {
    name, amount, since: now(),
    /* Kept so an undo can hand it straight back rather than trying to
       unwind the round a step at a time. */
    prev: from ? { name: from.name, amount: from.amount, since: from.since, prev: from.prev } : null,
  };
  if(!C.firstAt[name]) C.firstAt[name] = now();
  if(C.held[name] == null) C.held[name] = 0;
  C.steals++;

  say(`${from ? 'STOLEN' : 'CROWN '}  ${name} ${money(amount)}` +
      (from ? ` — off ${from.name} on ${secs(heldMs(from.name))}` : '') +
      `  ·  pot ${money(C.pot)}  ·  needs ${secs(Math.max(0, C.targetSec*1000 - heldMs(name)))} more`);
  mark();
  checkWin();
}

/* The only way to win while the round is live: your total time on the
   crown reaches the target. Checked on a tick as well as on a payment,
   because most of the time nothing is happening when somebody's clock
   crosses the line. */
function checkWin(){
  if(C.phase !== 'live' || C.paused || !C.holder) return;
  if(heldMs(C.holder.name) < C.targetSec * 1000) return;
  bank();
  const name = C.holder.name;
  C.phase = 'done';
  C.winner = { name, ms: C.held[name] || 0 };
  say(`WINNER  ${name} held it for ${secs(C.winner.ms)} and takes ${money(payout())}` +
      (C.cutPct ? ` (you keep ${money(yourCut())})` : ''));
  mark();
}

/* Ending by hand. Whoever is furthest along wins — the round stops
   early, so there has to be a winner, and the fair one is the person
   who has worn it longest. */
function cEnd(){
  if(C.phase === 'done') return;
  bank();
  const top = standings()[0];
  C.phase = 'done';
  C.winner = top && top.ms > 0 ? { name: top.name, ms: top.ms } : null;
  if(C.winner) say(`ENDED EARLY  ${C.winner.name} was ahead on ${secs(C.winner.ms)} and takes ${money(payout())}`);
  else say('ended with nobody having worn the crown');
  mark();
}

function cReset(){
  C.phase = 'idle'; C.pot = 0; C.holder = null; C.held = {}; C.firstAt = {};
  C.pays = []; C.shorts = []; C.givenBack = 0; C.kept = 0;
  C.steals = 0; C.winner = null; C.paused = false;
  say('round cleared'); mark();
}

function cPause(){
  if(C.paused){
    /* Time starts again from now, so the pause costs the holder
       nothing. */
    C.paused = false;
    if(C.holder) C.holder.since = now();
    say('resumed');
  } else {
    bank();
    C.paused = true;
    say('paused — nobody\'s clock is running');
  }
  mark();
}

/* Undo the newest payment. If it was the one that took the crown, the
   time since then belongs to the person it was taken from — they should
   never have lost it — so it is credited to them and the crown goes
   back. */
function cUndo(){
  const p = C.pays.shift();
  if(!p) return;
  C.pot -= p.amount;
  if(p.took && C.holder && C.holder.name === p.name){
    const elapsed = (C.phase === 'live' && !C.paused) ? Math.max(0, now() - C.holder.since) : 0;
    const back = C.holder.prev;
    C.holder = back ? { name: back.name, amount: back.amount, since: now(), prev: back.prev } : null;
    if(back) C.held[back.name] = (C.held[back.name] || 0) + elapsed;
    C.steals = Math.max(0, C.steals - 1);
    /* Somebody whose only turn has just been undone should disappear
       from the standings rather than sit there on 0:00. */
    if(!C.held[p.name]) { delete C.held[p.name]; delete C.firstAt[p.name]; }
    say(`undid ${p.name}'s ${money(p.amount)}` + (back ? ` — ${back.name} has the crown again` : ' — nobody is holding it'));
  } else {
    say(`undid ${p.name}'s ${money(p.amount)} — pot back to ${money(C.pot)}`);
  }
  mark();
}

/* Give back a payment that bought nothing. It comes out of wherever it
   went, and the line printed is the exact command to send in game. */
function cGiveBack(id){
  const s = C.shorts.find(x => x.id === Number(id));
  if(!s || s.back) return;
  s.back = true;
  if(s.why === 'under the minimum' && C.shortToPot) C.pot -= s.amount; else C.kept -= s.amount;
  C.givenBack += s.amount;
  say(`give back to ${s.name}:  /pay ${s.name} ${s.amount}`);
  mark();
}

const addPayment = (name, amount) => cPay(name, amount);

setInterval(checkWin, 100);

/* ================= commands from the panel ================= */
function handleCmd(c){
  const a = c.args || {};
  switch(c.name){
    case 'c.open':      cOpen(a); break;
    case 'c.pay':       cPay(a.name, a.amount); break;
    case 'c.end':       cEnd(); break;
    case 'c.reset':     cReset(); break;
    case 'c.pause':     cPause(); break;
    case 'c.undo':      cUndo(); break;
    case 'c.giveBack':  cGiveBack(a.id); break;
    case 'c.clearShort':C.shorts = C.shorts.filter(s => !s.back); mark(); break;
    case 'c.config':    for(const k of Object.keys(a)) if(k in C) C[k] = a[k];
                        say('settings updated'); mark(); break;
    case 'config':      if(a.ign){ ign = a.ign; paylog.setIgn(ign); mark(); } break;
  }
}

/* ================= http + websocket ================= */
const PAGE = path.join(__dirname, 'donut-crown.html');

function isLocal(req){
  const ip = (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
  return /^(::1|127\.|192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ip);
}

const server = http.createServer((req, res) => {
  if(!fs.existsSync(PAGE)){
    res.writeHead(404);
    return res.end('donut-crown.html must sit next to this script');
  }
  if(!isLocal(req) && !/^\/(display|overlay)/i.test(req.url || '')){
    res.writeHead(302, { Location: '/display' });
    return res.end();
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  fs.createReadStream(PAGE).pipe(res);
});

/* Everything the page needs to draw itself. `sv` is this PC's clock:
   the page works out the difference against its own and uses that when
   it counts the running holder up, so a hosted overlay on a machine
   whose clock is a few seconds out still shows the right time. */
const payload = () => ({
  t: 'state', m: C, s: { ign }, sv: now(),
  payout: payout(), yourCut: yourCut(), standings: standings().slice(0, 8),
});
const snapshot = () => JSON.stringify(payload());

const wss = new WebSocketServer({ server });
const clients = new Set();

wss.on('connection', (ws, req) => {
  const trusted = isLocal(req);
  clients.add(ws);
  ws.send(snapshot());
  ws.on('close', () => clients.delete(ws));
  ws.on('message', raw => {
    if(!trusted) return;
    let m; try { m = JSON.parse(raw.toString()); } catch { return; }
    if(m.t === 'cmd') handleCmd(m);
    if(m.t === 'payment') cPay(m.player, m.amount);
  });
  say(`overlay connected (${clients.size} open)${trusted ? '' : ' — view only'}`);
});

/* The running clock means the page always has something to redraw, but
   the state itself only needs sending when it changes — with one slow
   heartbeat so a hosted overlay that joined mid-round keeps its clock
   in step with this PC. */
setInterval(() => {
  if(!dirty || clients.size === 0) return;
  dirty = false;
  const s = snapshot();
  for(const c of clients) if(c.readyState === 1) c.send(s);
}, 20);
setInterval(() => { if(clients.size) mark(); }, 2000).unref();

/* ================= minecraft log watcher ================= */
function lanIP(){
  for(const list of Object.values(os.networkInterfaces()))
    for(const n of list || [])
      if(n.family === 'IPv4' && !n.internal) return n.address;
  return null;
}

const PORT_TRIES = [PORT, PORT + 10, PORT + 20, PORT + 30, PORT + 100];
let portAt = 0;
let livePort = PORT;

server.on('error', err => {
  if (err && err.code === 'EADDRINUSE' && portAt + 1 < PORT_TRIES.length) {
    const busy = PORT_TRIES[portAt];
    portAt += 1;
    livePort = PORT_TRIES[portAt];
    console.log(`  port ${busy} is being used by something else — trying ${livePort}`);
    return server.listen(livePort);
  }
  if (err && err.code === 'EADDRINUSE') {
    console.log(`
  Donut Overlays could not find a free port.

    Every port it tried (${PORT_TRIES.join(', ')}) is already being used on
    this PC. Usually that means Donut Overlays is already open in another
    window.

  What to do:

    1. Look along your taskbar for another black Donut Overlays window
       and close it. Then start this one again.

    2. If you cannot find one, an old copy may still be running in the
       background. Press Ctrl+Shift+Esc, click the Details tab, and end
       every  node.exe  in the list. Then start this one again.

  Nothing is broken and nothing has been lost.
`);
  } else {
    console.log('\n  Could not start: ' + (err && err.message ? err.message : err) + '\n');
  }
  process.exitCode = 1;
  setTimeout(() => process.exit(1), 50);
});

function openPanel(url) {
  if (process.env.DONUT_NO_OPEN) return;
  const cmd = process.platform === 'win32' ? `start "" "${url}"`
            : process.platform === 'darwin' ? `open "${url}"`
            : `xdg-open "${url}"`;
  try { require('child_process').exec(cmd, () => {}); } catch { /* the printed address still works */ }
}

let announced = false;
function announce() {
  if (announced) return;
  announced = true;
  const lan = lanIP();
  console.log(`
  Hold the Crown is running   ·   build ${BUILD}${REV}   (leave this window open — minimising is fine)

    LIVE Studio link source   http://localhost:${livePort}/display
    ...or if it rejects that  http://127.0.0.1:${livePort}/display${lan ? `
    ...or this one            http://${lan}:${livePort}/display` : ''}
    control panel on this PC  http://localhost:${livePort}/
${lan ? `    control panel on your phone  http://${lan}:${livePort}/   (same wifi)` : ''}
`);
  console.log(`  >>> YOUR CONTROLS:  http://localhost:${livePort}/   <<<
      (opening it for you now — if it does not appear, type that address
       into your browser. Use THIS number, not one from the website.)
`);
  openPanel(`http://localhost:${livePort}/`);

  paylog.setIgn(ign);
  paylog.startTail({ onPayment: addPayment, say, learn: LEARN });
  if(LEARN) say('learn mode on — every money-ish log line prints below.');
}

server.on('listening', announce);
server.listen(PORT);

/* ================= Donut Overlays uplink ================= */
try {
  const uplink = require('./uplink');
  const up = uplink.attach({ getPort: () => livePort, game: 'crown', getPayload: payload });
  setInterval(() => up.push(), 50).unref();
} catch (e) {
  console.log('  uplink unavailable (' + e.message + ') — running locally only');
}

/* Exported for the tests, which run the rules without a socket in
   sight. Requiring this file starts a server, so the tests set
   DONUT_NO_OPEN and close it; the exports are what they actually poke. */
module.exports = { C, cOpen, cPay, cEnd, cReset, cPause, cUndo, cGiveBack, checkWin,
                   heldMs, standings, payout, yourCut, handleCmd, server, money, secs };
