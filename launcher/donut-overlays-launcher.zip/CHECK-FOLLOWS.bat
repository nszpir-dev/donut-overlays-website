@echo off
title Donut Overlays - follows check
cd /d "%~dp0"

echo.
echo   Checking why follows are not arriving.
echo   Nothing is changed and nothing is spun - this only looks.
echo.

set "NODE=node"
if exist "node\node.exe" set "NODE=%~dp0node\node.exe"

"%NODE%" check-follows.js

echo.
echo   A copy was saved next to this file as  follows-report.txt
echo   Send that file over and it says exactly what is wrong.
echo.
pause
