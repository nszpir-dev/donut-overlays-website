#!/usr/bin/env node
/**
 * Donut Overlays — launcher
 * ---------------------------------------------------------------
 * The one thing a customer runs. Order matters:
 *
 *   1. sign in, while nothing else is writing to the console
 *   2. offer only the overlays their plan actually covers
 *   3. print that overlay's permanent link
 *   4. only then start the game, which prints its own banner
 *
 * One game at a time, on purpose: all three read the same Minecraft
 * chat, so running two would have both claiming the same payment.
 */
const readline = require('readline');
const uplink = require('./uplink');

const GAMES = {
  board:   { label: 'Elimination board', file: './donut-relay.js' },
  auction: { label: 'Live auction',      file: './donut-auction-relay.js' },
  money:   { label: 'Money game',        file: './donut-money-relay.js' },
  lastcall:{ label: 'Last Call',         file: './donut-lastcall-relay.js' },
};

function ask(question) {
  return new Promise(resolve => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(question, a => { rl.close(); resolve(a.trim()); });
  });
}

async function choose(available) {
  if (available.length === 1) {
    console.log('  Your plan covers the ' + GAMES[available[0]].label.toLowerCase() + '.');
    return available[0];
  }
  console.log('');
  console.log('  Which overlay are you running today?');
  console.log('');
  available.forEach((g, i) => console.log('    ' + (i + 1) + ')  ' + GAMES[g].label));
  console.log('');

  for (let tries = 0; tries < 5; tries++) {
    const a = await ask('  Type 1, 2 or 3 and press Enter: ');
    const n = parseInt(a, 10);
    if (n >= 1 && n <= available.length) return available[n - 1];
    console.log('  Just the number of one of the options above.');
  }
  return available[0];
}

(async () => {
  console.log('');
  console.log('  Donut Overlays');
  console.log('  ------------------------------------------------------------');

  let session = null;
  try {
    session = await uplink.signIn();
  } catch (err) {
    console.log('');
    console.log('  Could not reach donutoverlays.com (' + err.message + ').');
    console.log('  Starting the elimination board locally — your permanent');
    console.log('  overlay link will not update until the site is back.');
  }

  let game = 'board';
  if (session) {
    const available = session.links.links.map(l => l.game).filter(g => GAMES[g]);
    if (!available.length) {
      console.log('');
      console.log('  There is no active plan on this account.');
      console.log('  Start a free trial at ' + uplink.SITE + ' and run this again.');
      process.exit(0);
    }
    game = await choose(available);
    await uplink.begin(game, session);
  } else {
    uplink.useSession(null);
  }

  // Hand over to the game itself: reads the Minecraft log, runs the
  // round, serves the local control panel, exactly as it always has.
  require(GAMES[game].file);
})();
