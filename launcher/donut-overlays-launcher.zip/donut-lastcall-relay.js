#!/usr/bin/env node
/**
 * Last Call — standalone server
 * -------------------------------------------------------------
 * Everyone pays into one pot. Whoever paid LAST when the room goes
 * quiet takes it. Every payment snaps the countdown back to full, so
 * the round ends only when nobody is willing to top it — and the
 * bigger the pot gets, the more people pile in, which is precisely
 * what stops anyone winning.
 *
 * Size does not matter here. A 1M payment with two seconds left beats
 * a 500M payment made a minute ago. That is the entire point: it is a
 * game of nerve rather than a game of wallet.
 *
 * Payments after the clock stops cannot win. They are listed
 * separately so you can refund them or keep them.
 *
 * Run:    node donut-lastcall-relay.js
 *         node donut-lastcall-relay.js --learn        (find your pay message)
 *         node donut-lastcall-relay.js --test "line"  (check a pattern)
 *
 * LIVE Studio link source:  http://localhost:8093/display
 * Control panel:            http://localhost:8093/
 */

const http = require('http');
const fs   = require('fs');
const path = require('path');
const os   = require('os');

const PORT = 8093;

/* ================= pay-message parsing =================
   Lives in paylog.js now, shared by all three games. It used to be
   copy-pasted into each of them, which meant fixing a pay-message
   pattern for one game quietly left the other two broken. */
const paylog = require('./paylog');
const { clean, parseAmount, parseLine, looksLikePayment } = paylog;

/* ---------- one-off modes ---------- */
const argTest = process.argv.indexOf('--test');
if(argTest > -1){
  console.log(parseLine(process.argv[argTest + 1] || '') || 'no match — add a pattern for this line');
  process.exit(0);
}
const LEARN = process.argv.includes('--learn');

let WebSocketServer;
/* The real `ws` if it is installed, otherwise the small built-in one.
   Installing a package needs npm to exist, work, and reach the internet —
   which has already failed on real customers' PCs, and there is no reason
   for a stream to go down over it. */
try { ({ WebSocketServer } = require('ws')); }
catch { ({ WebSocketServer } = require('./ws-lite')); }

/* ================= Last Call =================
   Same payment stream as the money game, one rule changed: the winner is
   whoever paid LAST, not whoever paid most. Every payment shoves the
   clock back to full, so the round only ends when the room goes quiet —
   which is exactly what stops it ending. */
const L = {
  phase: 'idle',          // idle | live | done
  seed: 1000000,          // what you put in to start the pot
  minPay: 0,              // 0 = any amount counts and resets the clock
  cutPct: 0,              // your slice. 0 by default: the point is the winner takes it
  openSec: 30,            // how long the FIRST countdown runs
  resetSec: 10,           // what every payment snaps the clock back to
  endsAt: 0,
  paused: false,
  pausedLeft: 0,
  pot: 0,
  leader: null,           // { name, amount, at } — the last person to pay
  bids: [],               // newest first
  late: [],               // arrived after the clock stopped — you keep these
  kept: 0,
  rejected: [],           // under the minimum
  saves: 0,               // how many times the clock has been snatched back
  vouches: 6,
  uiScale: 1.15,
  layout: 'compact',
  cardW: 19,
};
let ign = 'mrchicken75';
let dirty = true;

const now = () => Date.now();
const mark = () => { dirty = true; };
const say = t => console.log(`  ${new Date().toLocaleTimeString([], {hour12:false})}  ${t}`);
function money(n){
  if(n >= 1e9) return '$' + +(n/1e9).toFixed(2) + 'B';
  if(n >= 1e6) return '$' + +(n/1e6).toFixed(2) + 'M';
  if(n >= 1e3) return '$' + +(n/1e3).toFixed(1) + 'K';
  return '$' + n;
}
const payout = () => Math.floor(L.pot * (100 - L.cutPct) / 100);
const yourCut = () => L.pot - payout() + L.kept;
const msLeft = () => L.paused ? (L.pausedLeft || 0) : (L.endsAt ? Math.max(0, L.endsAt - now()) : 0);

function lOpen(seed, minPay, openSec, resetSec){
  if(seed != null) L.seed = seed;
  if(minPay != null) L.minPay = minPay;
  if(openSec) L.openSec = openSec;
  if(resetSec) L.resetSec = resetSec;
  L.phase = 'live';
  L.pot = L.seed;
  L.leader = null; L.bids = []; L.late = []; L.kept = 0; L.rejected = []; L.saves = 0;
  L.paused = false; L.pausedLeft = 0;
  L.endsAt = now() + L.openSec * 1000;
  say(`round open · pot ${money(L.seed)} · ${L.openSec}s to start · every payment resets to ${L.resetSec}s`);
  mark();
}

function lPay(name, amount){
  name = String(name || '').trim().replace(/[^A-Za-z0-9_]/g, '').slice(0, 16);
  amount = Math.floor(Number(amount) || 0);
  if(!name || amount <= 0) return;

  /* After the clock stops nobody can take it back — the round is decided.
     The money is still yours, and it is listed so you can refund it if
     you would rather. */
  if(L.phase !== 'live'){
    L.late.push({ name, amount, at: now() });
    L.kept += amount;
    say(`LATE  ${name} ${money(amount)} — the round was already over`);
    return mark();
  }
  if(L.minPay > 0 && amount < L.minPay){
    L.rejected.push({ name, amount, why: 'under minimum' });
    say(`TOO SMALL  ${name} ${money(amount)} — under the ${money(L.minPay)} minimum, clock not reset`);
    return mark();
  }

  const wasLeft = msLeft();
  L.pot += amount;
  L.bids.unshift({ name, amount, at: now() });
  if(L.bids.length > 15) L.bids.pop();

  const stolen = L.leader && L.leader.name !== name;
  L.leader = { name, amount, at: now() };
  L.saves++;

  /* The whole game: the clock goes back to full, every single time.
     Never DOWN though — paying while the opening clock still has 25
     seconds on it should not chop it to ten. A payment can only ever buy
     time, which is the only version of this rule that is not baffling to
     the person who just paid. */
  L.paused = false; L.pausedLeft = 0;
  L.endsAt = Math.max(L.endsAt, now() + L.resetSec * 1000);

  say(`${stolen ? 'STOLEN' : 'LEAD  '}  ${name} ${money(amount)} with ${(wasLeft/1000).toFixed(1)}s left` +
      `  ·  pot ${money(L.pot)}  ·  winning ${money(payout())}`);
  mark();
}

function lEnd(){
  L.phase = 'done';
  L.endsAt = 0; L.paused = false; L.pausedLeft = 0;
  if(L.leader) say(`WINNER  ${L.leader.name} takes ${money(payout())}${L.cutPct ? ` (you keep ${money(yourCut())})` : ''}`);
  else say('the clock ran out with nobody paying');
  mark();
}
function lReset(){
  L.phase = 'idle'; L.pot = 0; L.leader = null; L.bids = []; L.late = [];
  L.kept = 0; L.rejected = []; L.endsAt = 0; L.paused = false; L.pausedLeft = 0; L.saves = 0;
  say('round cleared'); mark();
}
function lTogglePause(){
  L.paused = !L.paused;
  if(L.paused){ L.pausedLeft = L.endsAt ? Math.max(0, L.endsAt - now()) : 0; L.endsAt = 0; }
  else if(L.pausedLeft){ L.endsAt = now() + L.pausedLeft; L.pausedLeft = 0; }
  say(L.paused ? 'paused' : 'resumed'); mark();
}
const addPayment = (name, amount) => lPay(name, amount);

setInterval(() => {
  if(L.phase !== 'live' || L.paused) return;
  if(L.endsAt && now() >= L.endsAt) lEnd();
}, 50);

/* ================= commands from the panel ================= */
function handleCmd(c){
  const a = c.args || {};
  switch(c.name){
    case 'l.open':          lOpen(a.seed, a.minPay, a.openSec, a.resetSec); break;
    case 'l.pay':           lPay(a.name, a.amount); break;
    case 'l.end':           lEnd(); break;
    case 'l.reset':         lReset(); break;
    case 'l.pause':         lTogglePause(); break;
    case 'l.addTime':       if(L.endsAt){ L.endsAt = Math.max(now(), L.endsAt + Number(a.sec) * 1000); mark(); } break;
    case 'l.undo':          { const b = L.bids.shift();
                              if(b){
                                L.pot -= b.amount;
                                L.saves = Math.max(0, L.saves - 1);
                                /* the leader is simply whoever is now newest */
                                L.leader = L.bids[0] || null;
                                say(`undid ${b.name}'s ${money(b.amount)}`); mark();
                              } } break;
    case 'l.clearRejected': L.rejected = []; mark(); break;
    case 'l.config':        for(const k of Object.keys(a)) if(k in L) L[k] = a[k];
                            say('settings updated'); mark(); break;
    case 'config':          if(a.ign){ ign = a.ign; mark(); } break;
  }
}

/* ================= http + websocket ================= */
const PAGE = path.join(__dirname, 'donut-lastcall.html');

function isLocal(req){
  const ip = (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
  return /^(::1|127\.|192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ip);
}

const server = http.createServer((req, res) => {
  if(!fs.existsSync(PAGE)){
    res.writeHead(404);
    return res.end('donut-lastcall.html must sit next to this script');
  }
  if(!isLocal(req) && !/^\/(display|overlay)/i.test(req.url || '')){
    res.writeHead(302, { Location: '/display' });
    return res.end();
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  fs.createReadStream(PAGE).pipe(res);
});

const wss = new WebSocketServer({ server });
const clients = new Set();
const snapshot = () => JSON.stringify({
  t: 'state', m: L, s: { ign }, payout: payout(), yourCut: yourCut()
});

wss.on('connection', (ws, req) => {
  const trusted = isLocal(req);
  clients.add(ws);
  ws.send(snapshot());
  ws.on('close', () => clients.delete(ws));
  ws.on('message', raw => {
    if(!trusted) return;
    let m; try { m = JSON.parse(raw.toString()); } catch { return; }
    if(m.t === 'cmd') handleCmd(m);
    if(m.t === 'payment') lPay(m.player, m.amount);
  });
  say(`overlay connected (${clients.size} open)${trusted ? '' : ' — view only'}`);
});

setInterval(() => {
  if(!dirty || clients.size === 0) return;
  dirty = false;
  const s = snapshot();
  for(const c of clients) if(c.readyState === 1) c.send(s);
}, 20);

/* ================= minecraft log watcher =================
   Also paylog.js. Finding the right log is most of the work: hardly
   anyone plays through the vanilla launcher, and the old code only ever
   looked in .minecraft. */
/* your PC's address on the wifi, so you can drive the panel from your phone */
function lanIP(){
  for(const list of Object.values(os.networkInterfaces()))
    for(const n of list || [])
      if(n.family === 'IPv4' && !n.internal) return n.address;
  return null;
}
function lanIP(){
  for(const list of Object.values(os.networkInterfaces()))
    for(const n of list || [])
      if(n.family === 'IPv4' && !n.internal) return n.address;
  return null;
}

server.listen(PORT, () => {
  const lan = lanIP();
  console.log(`
  Last Call is running   (leave this window open — minimising is fine)

    LIVE Studio link source   http://localhost:${PORT}/display
    ...or if it rejects that  http://127.0.0.1:${PORT}/display${lan ? `
    ...or this one            http://${lan}:${PORT}/display` : ''}
    control panel on this PC  http://localhost:${PORT}/
${lan ? `    control panel on your phone  http://${lan}:${PORT}/   (same wifi)` : ''}
`);
  paylog.startTail({ onPayment: addPayment, say, learn: LEARN });
  if(LEARN) say('learn mode on — every money-ish log line prints below.');
});


/* ================= Donut Overlays uplink =================
   Mirrors this game up to donutoverlays.com so the streamer's permanent
   overlay link shows it. The game still runs entirely on this PC; if the
   site is unreachable everything above carries on exactly as before. */
try {
  const uplink = require('./uplink');
  const up = uplink.attach({ game: 'lastcall', getPayload: () => ({ t: 'state', m: L, s: { ign }, payout: payout(), yourCut: yourCut() }) });
  setInterval(() => up.push(), 50).unref();
} catch (e) {
  console.log('  uplink unavailable (' + e.message + ') — running locally only');
}
